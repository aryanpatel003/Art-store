
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Gem, Users, Lightbulb } from 'lucide-react';

export default function AboutPage() {
  return (
    <>
      <section className="bg-secondary py-12 md:py-20">
        <div className="container px-4 sm:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">About Canvas & Palette</h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">
            We believe that creativity is essential. Our store is dedicated to sourcing high-quality, reliable, and inspiring art materials for creators of all levels.
          </p>
        </div>
      </section>

      <section className="py-12 md:py-20">
        <div className="container px-4 sm:px-6 grid md:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[4/5] rounded-lg overflow-hidden">
            <Image
              src="https://placehold.co/800x1000.png"
              alt="Founder of Canvas & Palette"
              fill
              className="object-cover"
              data-ai-hint="artist studio"
            />
          </div>
          <div>
            <h2 className="text-3xl font-headline font-bold">Our Story</h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Founded in 2024, Canvas & Palette started with a simple idea: to create a space where artists could find reliable, high-quality tools to bring their visions to life. We are passionate about art and understand the importance of having materials you can trust.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Each product in our collection is carefully selected for its performance, durability, and value, ensuring that every artist, from beginner to professional, has access to the best supplies available.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-secondary py-12 md:py-20">
        <div className="container px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-headline font-bold">Our Values</h2>
            <p className="mt-2 text-lg text-muted-foreground">The principles that guide our store.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                <Gem className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold">Premium Materials</h3>
              <p className="mt-2 text-muted-foreground">We source the finest paints, papers, and tools to ensure exceptional results.</p>
            </div>
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold">For Every Artist</h3>
              <p className="mt-2 text-muted-foreground">Our collection serves everyone, from hobbyists to professional artists.</p>
            </div>
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                <Lightbulb className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold">Inspiration & Support</h3>
              <p className="mt-2 text-muted-foreground">We aim to be a source of inspiration and support for your creative journey.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-20">
        <div className="container px-4 sm:px-6 text-center">
            <h2 className="text-3xl font-headline font-bold">Start Creating</h2>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">
                Explore our collection and find the tools for your next masterpiece.
            </p>
            <Button asChild size="lg" className="mt-8">
                <Link href="/collections">Shop Now</Link>
            </Button>
        </div>
      </section>
    </>
  );
}
