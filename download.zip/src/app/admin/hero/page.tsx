
"use client";

import { useState } from "react";
import Image from "next/image";
import { PlusCircle, Pencil, Trash2, CheckCircle, MoreVertical } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { bannerItems as initialBannerItems } from "@/lib/data";
import { useToast } from "@/hooks/use-toast";
import type { HeroBanner } from "@/types";

const heroFormSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters."),
  description: z.string().min(10, "Description must be at least 10 characters."),
  buttonText: z.string().min(3, "Button text is required."),
  buttonLink: z.string().startsWith('/', "Link must start with a '/'. Ex: /collections"),
  image: z.string().url("Please enter a valid image URL."),
  alt: z.string().min(3, "Alt text is required for accessibility."),
  hint: z.string().min(3, "AI hint is required."),
});

type HeroFormValues = z.infer<typeof heroFormSchema>;

export default function HeroAdminPage() {
  const { toast } = useToast();
  const [banners, setBanners] = useState<HeroBanner[]>(initialBannerItems);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<'add' | 'edit'>('add');
  const [selectedBanner, setSelectedBanner] = useState<HeroBanner | null>(null);

  const form = useForm<HeroFormValues>({
    resolver: zodResolver(heroFormSchema),
    defaultValues: {
      title: "",
      description: "",
      buttonText: "",
      buttonLink: "/collections",
      image: "",
      alt: "",
      hint: "",
    },
  });

  const handleAddNew = () => {
    setDialogMode('add');
    setSelectedBanner(null);
    form.reset();
    setIsFormDialogOpen(true);
  };
  
  const handleEdit = (banner: HeroBanner) => {
    setDialogMode('edit');
    setSelectedBanner(banner);
    form.reset(banner);
    setIsFormDialogOpen(true);
  };

  const handleDelete = (banner: HeroBanner) => {
      setSelectedBanner(banner);
      setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
      if (!selectedBanner) return;
      setBanners(banners.filter(b => b.id !== selectedBanner.id));
      toast({
        title: "Banner Deleted",
        description: `Banner "${selectedBanner.title}" has been removed.`,
        variant: "destructive",
      });
      setIsDeleteDialogOpen(false);
      setSelectedBanner(null);
  };

  function onSubmit(data: HeroFormValues) {
    if (dialogMode === 'add') {
      const newBanner: HeroBanner = {
        id: `banner-${Date.now()}`,
        ...data,
      };
      setBanners([newBanner, ...banners]);
      toast({
          title: "Banner Added!",
          description: `${data.title} has been created.`,
          action: <CheckCircle className="text-green-500" />,
      });
    } else if (selectedBanner) {
        setBanners(banners.map(b => b.id === selectedBanner.id ? { ...b, ...data, id: b.id } : b));
        toast({
            title: "Banner Updated!",
            description: `Banner "${data.title}" has been updated.`,
            action: <CheckCircle className="text-green-500" />,
        });
    }
    
    form.reset();
    setIsFormDialogOpen(false);
    setSelectedBanner(null);
  }

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Hero Section Banners</h1>
          <p className="text-muted-foreground">Manage the banners in your homepage carousel.</p>
        </div>
        <Button onClick={handleAddNew}>
            <PlusCircle className="mr-2" />
            Add Banner
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {banners.map((banner) => (
          <Card key={banner.id}>
            <CardHeader className="p-0">
                <div className="relative aspect-video w-full">
                    <Image
                        src={banner.image}
                        alt={banner.alt}
                        fill
                        className="object-cover rounded-t-lg"
                        data-ai-hint={banner.hint}
                    />
                </div>
                <div className="p-4">
                    <CardTitle className="flex justify-between items-start">
                        <span className="text-lg">{banner.title}</span>
                         <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                  <Button aria-haspopup="true" size="icon" variant="ghost" className="h-8 w-8 -mt-1 -mr-1">
                                      <MoreVertical className="h-4 w-4" />
                                      <span className="sr-only">Toggle menu</span>
                                  </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                  <DropdownMenuItem onSelect={() => handleEdit(banner)}>
                                    <Pencil className="mr-2 h-4 w-4" />
                                    <span>Edit</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onSelect={() => handleDelete(banner)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    <span>Delete</span>
                                  </DropdownMenuItem>
                              </DropdownMenuContent>
                          </DropdownMenu>
                    </CardTitle>
                    <CardDescription>{banner.description}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="p-4 pt-0">
                <Button asChild variant="outline" size="sm" className="w-full">
                    <a href={banner.buttonLink}>{banner.buttonText}</a>
                </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
          <DialogContent className="sm:max-w-2xl p-0">
              <DialogHeader className="p-6 pb-4">
                  <DialogTitle>{dialogMode === 'add' ? 'Add New Banner' : 'Edit Banner'}</DialogTitle>
                  <DialogDescription>
                      {dialogMode === 'add' 
                        ? "Fill in the details for the new hero banner."
                        : `Editing banner: ${selectedBanner?.title}`
                      }
                  </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="space-y-4 px-6 py-2 max-h-[60vh] overflow-y-auto">
                      <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Title</FormLabel>
                                  <FormControl>
                                      <Input placeholder="e.g. Unleash Your Creativity" {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Description</FormLabel>
                                  <FormControl>
                                      <Textarea placeholder="Describe the banner's message..." {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="buttonText"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Button Text</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g. Shop Now" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="buttonLink"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Button Link</FormLabel>
                                    <FormControl>
                                        <Input placeholder="/collections" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                          />
                      </div>
                      <FormField
                          control={form.control}
                          name="image"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Image URL</FormLabel>
                                  <FormControl>
                                      <Input placeholder="https://placehold.co/1200x800.png" {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                            control={form.control}
                            name="alt"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Alt Text</FormLabel>
                                    <FormControl>
                                        <Input placeholder="Image alt text" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="hint"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>AI Hint</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g. artist painting" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                      </div>
                    </div>
                    <DialogFooter className="p-6 pt-4 mt-2 border-t">
                        <Button type="button" variant="ghost" onClick={() => setIsFormDialogOpen(false)}>Cancel</Button>
                        <Button type="submit">{dialogMode === 'add' ? 'Save Banner' : 'Save Changes'}</Button>
                    </DialogFooter>
                  </form>
              </Form>
          </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                    This will permanently delete the <span className="font-bold">{selectedBanner?.title}</span> banner.
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
                    Delete
                </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
