
"use client";

import { useState } from "react";
import type { DateRange } from "react-day-picker";
import Image from "next/image";
import type { Order } from "@/lib/data";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { format } from "date-fns";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { orders as initialOrders } from "@/lib/data";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { File, Calendar as CalendarIcon, MapPin, FileText } from "lucide-react";

const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', currencyDisplay: 'code' }).format(price);
};

const formatDate = (date: Date) => {
    return date.toLocaleString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Kolkata'
    });
};

// Extend jsPDF with autoTable
interface jsPDFWithAutoTable extends jsPDF {
  autoTable: (options: any) => jsPDF;
}

const generateInvoicePage = (doc: jsPDFWithAutoTable, order: Order) => {
    const pageWidth = doc.internal.pageSize.getWidth();

    // Header
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("Rose Bloom Boutique", 14, 20);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("Invoice", pageWidth - 14, 20, { align: 'right' });
    doc.text(`Order #${order.id}`, pageWidth - 14, 25, { align: 'right' });
    doc.text(`Date: ${format(order.date, "LLL dd, yyyy")}`, pageWidth - 14, 30, { align: 'right' });

    doc.setLineWidth(0.5);
    doc.line(14, 35, pageWidth - 14, 35);

    // Addresses
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Bill To:", 14, 45);
    doc.setFont("helvetica", "normal");
    const addr = order.shippingAddress;
    let addrY = 52;
    doc.text(`${addr.name}`, 14, addrY);
    addrY += 5;
    doc.text(`${addr.addressLine1}`, 14, addrY);
    addrY += 5;
    if(addr.addressLine2) {
        doc.text(`${addr.addressLine2}`, 14, addrY);
        addrY += 5;
    }
    doc.text(`${addr.city}, ${addr.state} ${addr.zip}`, 14, addrY);
    addrY += 5;
    doc.text(`${addr.country}`, 14, addrY);

    // Items Table
    const tableColumn = ["#", "Item Description", "Qty", "Rate", "Amount"];
    const tableRows: any[][] = [];

    const orderSubtotal = order.items.reduce((acc, item) => acc + item.price * item.quantity, 0);
    const orderTax = orderSubtotal * 0.18;
    const orderShipping = 500;

    order.items.forEach((item, index) => {
        const itemData = [
            index + 1,
            item.name,
            item.quantity,
            formatPrice(item.price),
            formatPrice(item.price * item.quantity)
        ];
        tableRows.push(itemData);
    });

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: addrY + 10,
        theme: 'grid',
        headStyles: {
            fillColor: [32, 34, 37],
            textColor: 255,
            fontStyle: 'bold',
        },
        columnStyles: {
            0: { cellWidth: 10, halign: 'center' },
            1: { cellWidth: 'auto' },
            2: { cellWidth: 15, halign: 'right' },
            3: { cellWidth: 25, halign: 'right' },
            4: { cellWidth: 30, halign: 'right' },
        }
    });

    // Summary
    const finalY = (doc as any).lastAutoTable.finalY;
    const summaryX = pageWidth - 60;
    const summaryXValue = pageWidth - 14;

    doc.setFontSize(10);
    doc.text("Subtotal:", summaryX, finalY + 10);
    doc.text(formatPrice(orderSubtotal), summaryXValue, finalY + 10, { align: 'right' });

    doc.text("Tax (18%):", summaryX, finalY + 15);
    doc.text(formatPrice(orderTax), summaryXValue, finalY + 15, { align: 'right' });

    doc.text("Shipping:", summaryX, finalY + 20);
    doc.text(formatPrice(orderShipping), summaryXValue, finalY + 20, { align: 'right' });
    
    doc.setLineWidth(0.2);
    doc.line(summaryX - 2, finalY + 23, summaryXValue, finalY + 23);

    doc.setFont("helvetica", "bold");
    doc.text("Grand Total:", summaryX, finalY + 28);
    doc.text(formatPrice(order.total), summaryXValue, finalY + 28, { align: 'right' });


    // Footer
    const pageHeight = doc.internal.pageSize.getHeight();
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("Thank you for your business!", pageWidth / 2, pageHeight - 15, { align: 'center' });
}

export default function OrdersPage() {
  const [orders, setOrders] = useState(initialOrders);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [date, setDate] = useState<DateRange | undefined>();


  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setIsDetailsOpen(true);
  };
  
  const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
    if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
    }
    setOrders(prevOrders => prevOrders.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
    ));
  };

  const subtotal = selectedOrder?.items.reduce((acc, item) => acc + item.price * item.quantity, 0) ?? 0;
  const shipping = 500; // Example shipping cost
  const tax = subtotal * 0.18; // Example tax
  
  const filteredOrders = orders.filter(order => {
    const statusMatch = statusFilter === 'all' || order.status.toLowerCase() === statusFilter;
    
    // Date filtering logic
    const dateMatch = (() => {
        if (!date || !date.from) return true; // No date filter applied
        const orderDate = order.date;
        if (date.to) {
            // Range selection
            return orderDate >= date.from && orderDate <= new Date(date.to.setHours(23, 59, 59, 999));
        }
        // Single day selection
        return orderDate >= date.from && orderDate < new Date(new Date(date.from).setDate(date.from.getDate() + 1));
    })();

    return statusMatch && dateMatch;
  });

  const handleExportCSV = () => {
    const headers = [
      "Order ID", "Customer Name", "Customer Email", "Date", "Status", "Total", 
      "Items", "Shipping Name", "Address Line 1", "Address Line 2", "City", "State", "ZIP", "Country"
    ];

    const rows = filteredOrders.map(order => {
      const itemsString = order.items.map(item => `${item.name} (Qty: ${item.quantity}, Price: ${item.price})`).join('; ');
      return [
        order.id,
        order.customerName,
        order.customerEmail,
        formatDate(order.date),
        order.status,
        formatPrice(order.total),
        itemsString,
        order.shippingAddress.name,
        order.shippingAddress.addressLine1,
        order.shippingAddress.addressLine2 || '',
        order.shippingAddress.city,
        order.shippingAddress.state,
        order.shippingAddress.zip,
        order.shippingAddress.country
      ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `orders_export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF() as jsPDFWithAutoTable;
    
    doc.setFontSize(18);
    doc.text('Order Report', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);

    const dateRangeText = date && date.from 
        ? `Date Range: ${format(date.from, "LLL dd, y")}${date.to ? ` - ${format(date.to, "LLL dd, y")}` : ''}`
        : 'Date Range: All Time';
    doc.text(dateRangeText, 14, 30);

    const tableColumn = ["Order ID", "Date", "Customer", "Shipping Address", "Items", "Total"];
    const tableRows: any[][] = [];

    filteredOrders.forEach(order => {
        const orderData = [
            order.id,
            format(order.date, "dd-MM-yyyy HH:mm"),
            `${order.customerName}\n${order.customerEmail}`,
            `${order.shippingAddress.name}\n${order.shippingAddress.addressLine1}${order.shippingAddress.addressLine2 ? `\n${order.shippingAddress.addressLine2}` : ''}\n${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.zip}`,
            order.items.map(item => `${item.name} (x${item.quantity})`).join('\n'),
            formatPrice(order.total)
        ];
        tableRows.push(orderData);
    });

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 35,
        styles: {
            fontSize: 8,
            cellPadding: 2,
            valign: 'middle',
        },
        headStyles: {
            fillColor: [34, 115, 62],
            textColor: 255,
            fontStyle: 'bold',
        },
        columnStyles: {
            0: { cellWidth: 15 },
            1: { cellWidth: 22 },
            2: { cellWidth: 35 },
            3: { cellWidth: 40 },
            4: { cellWidth: 'auto' },
            5: { cellWidth: 25, halign: 'right' },
        }
    });

    doc.save(`orders_report_${new Date().toISOString().slice(0,10)}.pdf`);
  };

  const handleGenerateInvoice = (order: Order) => {
    const doc = new jsPDF() as jsPDFWithAutoTable;
    generateInvoicePage(doc, order);
    doc.save(`Invoice_${order.id}.pdf`);
  };

  const handleExportAllInvoices = () => {
    if (filteredOrders.length === 0) {
      alert("No orders available to export invoices for.");
      return;
    }
    const doc = new jsPDF() as jsPDFWithAutoTable;
    
    filteredOrders.forEach((order, index) => {
        generateInvoicePage(doc, order);
        if (index < filteredOrders.length - 1) {
            doc.addPage();
        }
    });

    doc.save(`invoices_export_${new Date().toISOString().slice(0,10)}.pdf`);
  };


  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-4">
        <Popover>
            <PopoverTrigger asChild>
                <Button
                    id="date"
                    variant={"outline"}
                    className={cn(
                        "w-full sm:w-[260px] justify-start text-left font-normal",
                        !date && "text-muted-foreground"
                    )}
                >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date?.from ? (
                        date.to ? (
                            <>
                                {format(date.from, "LLL dd, y")} -{" "}
                                {format(date.to, "LLL dd, y")}
                            </>
                        ) : (
                            format(date.from, "LLL dd, y")
                        )
                    ) : (
                        <span>Pick a date range</span>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={date?.from}
                    selected={date}
                    onSelect={setDate}
                    numberOfMonths={2}
                />
            </PopoverContent>
        </Popover>

        <Tabs value={statusFilter} onValueChange={setStatusFilter} className="overflow-x-auto">
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="processing">Processing</TabsTrigger>
            <TabsTrigger value="shipped">Shipped</TabsTrigger>
            <TabsTrigger value="delivered">Delivered</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="ml-auto flex-shrink-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline">
                <File className="h-4 w-4 mr-2" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onSelect={handleExportCSV}>Export as CSV</DropdownMenuItem>
              <DropdownMenuItem onSelect={handleExportPDF}>Export Report (PDF)</DropdownMenuItem>
              <DropdownMenuItem onSelect={handleExportAllInvoices}>Export Invoices (PDF)</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      <Card>
        <CardHeader className="p-4 md:p-6">
          <CardTitle>Orders</CardTitle>
          <CardDescription>
            A list of all recent orders. Click an order to view details.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {/* Mobile View */}
          <div className="grid gap-4 p-4 md:hidden">
            {filteredOrders.map((order) => (
              <Card key={order.id} onClick={() => handleViewDetails(order)} className="cursor-pointer hover:bg-muted/50">
                <CardHeader className="flex flex-row items-start justify-between gap-4 p-4">
                  <div className="flex-1">
                    <CardTitle className="text-base font-semibold">Order #{order.id}</CardTitle>
                    <CardDescription className="text-sm">{order.customerName}</CardDescription>
                  </div>
                  <Badge
                    className={cn(
                      'text-xs capitalize',
                      order.status === 'Shipped' && 'bg-blue-100 text-blue-800',
                      order.status === 'Processing' && 'bg-yellow-100 text-yellow-800',
                      order.status === 'Delivered' && 'bg-green-100 text-green-800',
                      order.status === 'Cancelled' && 'bg-red-100 text-red-800'
                    )}
                    variant={order.status === 'Delivered' ? 'default' : 'secondary'}
                  >
                    {order.status}
                  </Badge>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <Separator className="mb-4" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Date</span>
                    <span className="font-medium text-foreground">{formatDate(order.date)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground mt-2">
                    <span>Total</span>
                    <span className="font-semibold text-foreground">{formatPrice(order.total)}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Desktop View */}
          <Table className="hidden md:table">
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead className="hidden sm:table-cell">Status</TableHead>
                <TableHead className="hidden md:table-cell">Date</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>
                    <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>
                    <div className="font-medium">{order.customerName}</div>
                    <div className="hidden text-sm text-muted-foreground md:inline">
                      {order.customerEmail}
                    </div>

                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                      <Badge
                          className={cn(
                              'text-xs capitalize',
                              order.status === 'Shipped' && 'bg-blue-100 text-blue-800',
                              order.status === 'Processing' && 'bg-yellow-100 text-yellow-800',
                              order.status === 'Delivered' && 'bg-green-100 text-green-800',
                              order.status === 'Cancelled' && 'bg-red-100 text-red-800'
                          )}
                          variant={order.status === 'Delivered' ? 'default' : 'secondary'}
                      >
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">{formatDate(order.date)}</TableCell>
                  <TableCell className="text-right">{formatPrice(order.total)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" onClick={() => handleViewDetails(order)}>
                        View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="sm:max-w-2xl">
          {selectedOrder && (
            <>
              <DialogHeader>
                <DialogTitle>Order #{selectedOrder.id}</DialogTitle>
                <DialogDescription>
                  Details for order by {selectedOrder.customerName} placed on {formatDate(selectedOrder.date)}.
                </DialogDescription>
              </DialogHeader>
              <div className="overflow-y-auto max-h-[60vh] -mr-6 pr-6">
                <div className="grid gap-6 py-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Order Items</h4>
                    <Separator />
                    <div className="space-y-4">
                      {selectedOrder.items.map(item => (
                        <div key={item.id} className="flex items-start gap-4">
                            <div className="relative h-16 w-16 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                                <Image src={item.image} alt={item.name} fill className="object-cover" />
                            </div>
                            <div className="flex-1">
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                            </div>
                            <p className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                      <h4 className="font-semibold">Financial Summary</h4>
                      <Separator />
                      <div className="space-y-1 text-sm">
                          <div className="flex justify-between"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
                          <div className="flex justify-between"><span>Shipping</span><span>{formatPrice(shipping)}</span></div>
                          <div className="flex justify-between"><span>Taxes (18%)</span><span>{formatPrice(tax)}</span></div>
                          <Separator className="my-2" />
                          <div className="flex justify-between font-semibold"><span>Grand Total</span><span>{formatPrice(selectedOrder.total)}</span></div>
                      </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold">Shipping Address</h4>
                    <Separator />
                    <div className="text-sm text-muted-foreground flex items-start gap-4">
                        <MapPin className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <div>
                            <p className="font-medium text-foreground">{selectedOrder.shippingAddress.name}</p>
                            <p>{selectedOrder.shippingAddress.addressLine1}</p>
                            {selectedOrder.shippingAddress.addressLine2 && <p>{selectedOrder.shippingAddress.addressLine2}</p>}
                            <p>{selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} {selectedOrder.shippingAddress.zip}</p>
                            <p>{selectedOrder.shippingAddress.country}</p>
                        </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold">Update Status</h4>
                    <Separator />
                     <div className="flex items-center gap-4">
                          <p className="text-sm font-medium">Order Status:</p>
                          <Select
                              value={selectedOrder.status}
                              onValueChange={(newStatus: Order['status']) => handleStatusChange(selectedOrder.id, newStatus)}
                          >
                              <SelectTrigger className="w-[180px]">
                                  <SelectValue placeholder="Change status" />
                              </SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="Processing">Processing</SelectItem>
                                  <SelectItem value="Shipped">Shipped</SelectItem>
                                  <SelectItem value="Delivered">Delivered</SelectItem>
                                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                              </SelectContent>
                          </Select>
                     </div>
                  </div>
                </div>
              </div>
              <DialogFooter className="pt-4 mt-4 border-t sm:justify-start">
                  <Button 
                      variant="outline" 
                      onClick={() => handleGenerateInvoice(selectedOrder)}
                      disabled={!selectedOrder}
                  >
                      <FileText className="h-4 w-4 mr-2" />
                      Generate Invoice
                  </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
