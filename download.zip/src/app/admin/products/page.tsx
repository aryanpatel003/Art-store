
"use client";

import { useState } from "react";
import Image from "next/image"
import { MoreHorizontal, PlusCircle, Pencil, Trash2, CheckCircle, File } from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import jsPDF from "jspdf";
import "jspdf-autotable";

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { products as initialProducts } from "@/lib/data"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@/types";

// Extend jsPDF with autoTable
interface jsPDFWithAutoTable extends jsPDF {
  autoTable: (options: any) => jsPDF;
}

const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', currencyDisplay: 'code' }).format(price);
};

const productFormSchema = z.object({
  name: z.string().min(3, "Product name must be at least 3 characters."),
  description: z.string().min(10, "Description must be at least 10 characters."),
  price: z.coerce.number({invalid_type_error: "Price must be a number"}).positive("Price must be a positive number."),
  stock: z.coerce.number({invalid_type_error: "Stock must be a number"}).int().min(0, "Stock cannot be negative."),
  category: z.string().min(2, "Category is required."),
  imageUrl: z.string().url("Please enter a valid image URL."),
});

type ProductFormValues = z.infer<typeof productFormSchema>;


export default function ProductsPage() {
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<'add' | 'edit'>('add');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      stock: 0,
      category: "",
      imageUrl: "",
    },
  });

  const handleAddNew = () => {
    setDialogMode('add');
    setSelectedProduct(null);
    form.reset({
      name: "",
      description: "",
      price: 0,
      stock: 0,
      category: "",
      imageUrl: "",
    });
    setIsFormDialogOpen(true);
  };
  
  const handleEdit = (product: Product) => {
    setDialogMode('edit');
    setSelectedProduct(product);
    form.reset({
        name: product.name,
        description: product.description,
        price: product.price,
        stock: product.stock,
        category: product.category,
        imageUrl: product.images[0] || '',
    });
    setIsFormDialogOpen(true);
  };

  const handleDelete = (product: Product) => {
      setSelectedProduct(product);
      setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
      if (!selectedProduct) return;
      setProducts(products.filter(p => p.id !== selectedProduct.id));
      toast({
        title: "Product Deleted",
        description: `Product "${selectedProduct.name}" has been removed.`,
        variant: "destructive",
      });
      setIsDeleteDialogOpen(false);
      setSelectedProduct(null);
  };

  function onSubmit(data: ProductFormValues) {
    if (dialogMode === 'add') {
      const newProduct: Product = {
        id: `prod-${Date.now()}`,
        ...data,
        images: [data.imageUrl],
        sizes: ['One Size'],
        colors: ['Default'],
      };
      setProducts([newProduct, ...products]);
      toast({
          title: "Product Added!",
          description: `${data.name} has been created.`,
          action: <CheckCircle className="text-green-500" />,
      });
    } else if (selectedProduct) {
        setProducts(products.map(p => p.id === selectedProduct.id ? { ...p, ...data, images: [data.imageUrl] } : p));
        toast({
            title: "Product Updated!",
            description: `Product "${data.name}" has been updated.`,
            action: <CheckCircle className="text-green-500" />,
        });
    }
    
    form.reset();
    setIsFormDialogOpen(false);
    setSelectedProduct(null);
  }

  const handleExportCSV = () => {
    const headers = ["Product ID", "Name", "Description", "Category", "Price", "Stock", "Image URL"];
    
    const rows = products.map(product => {
      const description = product.description.replace(/"/g, '""');
      return [
        product.id,
        product.name,
        `"${description}"`,
        product.category,
        product.price,
        product.stock,
        product.images[0]
      ].join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `products_export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF() as jsPDFWithAutoTable;
    
    doc.setFontSize(18);
    doc.text('Product Report', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Date: ${new Date().toLocaleDateString('en-IN')}`, 14, 30);

    const tableColumn = ["ID", "Name", "Category", "Stock", "Price"];
    const tableRows: any[][] = [];

    products.forEach(product => {
        const productData = [
            product.id,
            product.name,
            product.category,
            product.stock,
            formatPrice(product.price)
        ];
        tableRows.push(productData);
    });

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 35,
        theme: 'grid',
        styles: {
            fontSize: 9,
            cellPadding: 2,
            valign: 'middle',
        },
        headStyles: {
            fillColor: [32, 34, 37],
            textColor: 255,
            fontStyle: 'bold',
            halign: 'center',
        },
        columnStyles: {
            0: { cellWidth: 15, halign: 'center' },
            1: { cellWidth: 85 },
            2: { cellWidth: 30 },
            3: { cellWidth: 20, halign: 'right' },
            4: { cellWidth: 30, halign: 'right' },
        }
    });

    doc.save(`products_report_${new Date().toISOString().slice(0,10)}.pdf`);
  };

  return (
    <>
      <Tabs defaultValue="all">
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="draft">Draft</TabsTrigger>
            <TabsTrigger value="archived" className="hidden sm:flex">
              Archived
            </TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline">
                  <File className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onSelect={handleExportCSV}>Export as CSV</DropdownMenuItem>
                <DropdownMenuItem onSelect={handleExportPDF}>Export Report (PDF)</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" onClick={handleAddNew}>
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Product
            </Button>
          </div>
        </div>
        <TabsContent value="all">
          {/* Mobile View */}
          <div className="grid gap-4 md:hidden">
              {products.map((product) => (
                  <Card key={product.id}>
                      <CardHeader className="flex flex-row items-center gap-4 p-4">
                          <div className="relative h-20 w-20 flex-shrink-0">
                          <Image
                              alt={product.name}
                              className="aspect-square rounded-md object-cover bg-secondary"
                              fill
                              src={product.images[0]}
                          />
                          </div>
                          <div className="flex-grow">
                              <CardTitle className="text-base">{product.name}</CardTitle>
                              <div className="text-sm text-muted-foreground mt-1">
                                  <Badge variant="outline">{product.category}</Badge>
                              </div>
                          </div>
                          <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                  <Button aria-haspopup="true" size="icon" variant="ghost">
                                      <MoreHorizontal className="h-4 w-4" />
                                      <span className="sr-only">Toggle menu</span>
                                  </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem onSelect={() => handleEdit(product)}>
                                    <Pencil className="mr-2 h-4 w-4" />
                                    <span>Edit</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onSelect={() => handleDelete(product)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    <span>Delete</span>
                                  </DropdownMenuItem>
                              </DropdownMenuContent>
                          </DropdownMenu>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                          <Separator className="mb-4" />
                          <div className="flex justify-between text-sm text-muted-foreground">
                              <span>Price</span>
                              <span className="font-semibold text-foreground">{formatPrice(product.price)}</span>
                          </div>
                          <div className="flex justify-between text-sm text-muted-foreground mt-2">
                              <span>Stock</span>
                              <span>{product.stock} in stock</span>
                          </div>
                      </CardContent>
                  </Card>
              ))}
          </div>

          {/* Desktop View */}
          <Card className="hidden md:block">
            <CardHeader className="p-4">
              <CardTitle>Products</CardTitle>
              <CardDescription>
                Manage your products and view their sales performance.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="hidden w-[100px] sm:table-cell">
                      <span className="sr-only">Image</span>
                    </TableHead>
                    <TableHead className="p-2 sm:p-4">Name</TableHead>
                    <TableHead className="p-2 sm:p-4">Category</TableHead>
                    <TableHead className="hidden md:table-cell p-2 sm:p-4">
                      Stock
                    </TableHead>
                    <TableHead className="text-right p-2 sm:p-4">Price</TableHead>
                    <TableHead>
                      <span className="sr-only">Actions</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell className="hidden sm:table-cell p-2 sm:p-4">
                        <Image
                          alt={product.name}
                          className="aspect-square rounded-md object-cover bg-secondary"
                          height="64"
                          src={product.images[0]}
                          width="64"
                        />
                      </TableCell>
                      <TableCell className="font-medium p-2 sm:p-4">{product.name}</TableCell>
                      <TableCell className="p-2 sm:p-4">
                        <Badge variant="outline">{product.category}</Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell p-2 sm:p-4">
                        {product.stock} in stock
                      </TableCell>
                      <TableCell className="text-right p-2 sm:p-4">{formatPrice(product.price)}</TableCell>
                      <TableCell className="p-2 sm:p-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              aria-haspopup="true"
                              size="icon"
                              variant="ghost"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Toggle menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onSelect={() => handleEdit(product)}>
                              <Pencil className="mr-2 h-4 w-4" />
                              <span>Edit</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onSelect={() => handleDelete(product)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Delete</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="p-4">
              <div className="text-xs text-muted-foreground">
                Showing <strong>1-{products.length}</strong> of <strong>{products.length}</strong>{" "}
                products
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
          <DialogContent className="sm:max-w-[480px] p-0">
              <DialogHeader className="p-6 pb-4">
                  <DialogTitle>{dialogMode === 'add' ? 'Add New Product' : 'Edit Product'}</DialogTitle>
                  <DialogDescription>
                      {dialogMode === 'add' 
                        ? "Fill in the details below to add a new product to your store."
                        : `Editing product: ${selectedProduct?.name}`
                      }
                  </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="space-y-4 px-6 py-2 max-h-[60vh] overflow-y-auto">
                      <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Product Name</FormLabel>
                                  <FormControl>
                                      <Input placeholder="e.g. Watercolor Set" {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Description</FormLabel>
                                  <FormControl>
                                      <Textarea placeholder="Describe the product..." {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="price"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Price (INR)</FormLabel>
                                        <FormControl>
                                            <Input type="number" step="0.01" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="stock"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Stock</FormLabel>
                                        <FormControl>
                                            <Input type="number" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                      </div>
                      <FormField
                          control={form.control}
                          name="category"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <FormControl>
                                      <Input placeholder="e.g. Paints" {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <FormField
                          control={form.control}
                          name="imageUrl"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Image URL</FormLabel>
                                  <FormControl>
                                      <Input placeholder="https://placehold.co/600x800.png" {...field} />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                    </div>
                    <DialogFooter className="p-6 pt-4 border-t">
                        <Button type="button" variant="ghost" onClick={() => setIsFormDialogOpen(false)}>Cancel</Button>
                        <Button type="submit">{dialogMode === 'add' ? 'Save Product' : 'Save Changes'}</Button>
                    </DialogFooter>
                  </form>
              </Form>
          </DialogContent>
      </Dialog>
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the
                    <span className="font-bold"> {selectedProduct?.name} </span>
                    product.
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
                    Delete
                </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
