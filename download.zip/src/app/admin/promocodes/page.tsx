
"use client";

import { useState } from "react";
import { MoreHorizontal, PlusCircle, Calendar as CalendarIcon, CheckCircle, Trash2, Pencil } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from "date-fns";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { promocodes as initialPromocodes } from "@/lib/admin-data";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import type { Promocode } from "@/types";

const promocodeSchema = z.object({
  code: z.string().min(3, "Code must be at least 3 characters.").toUpperCase(),
  discountType: z.enum(["percentage", "fixed"]),
  discountValue: z.coerce.number().positive("Discount value must be positive."),
  expiryDate: z.date(),
  status: z.enum(["active", "inactive"]),
});

type PromocodeFormValues = z.infer<typeof promocodeSchema>;

export default function PromocodesPage() {
  const { toast } = useToast();
  const [promocodes, setPromocodes] = useState(initialPromocodes);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<'add' | 'edit'>('add');
  const [selectedPromo, setSelectedPromo] = useState<Promocode | null>(null);

  const form = useForm<PromocodeFormValues>({
    resolver: zodResolver(promocodeSchema),
    defaultValues: {
      code: "",
      discountType: "percentage",
      discountValue: 10,
      expiryDate: new Date(),
      status: "active",
    },
  });

  const handleAddNew = () => {
    setDialogMode('add');
    setSelectedPromo(null);
    form.reset({
      code: "",
      discountType: "percentage",
      discountValue: 10,
      expiryDate: new Date(new Date().setHours(0,0,0,0)), // Start of day
      status: "active",
    });
    setIsFormDialogOpen(true);
  };

  const handleEdit = (promo: Promocode) => {
    setDialogMode('edit');
    setSelectedPromo(promo);
    form.reset({
        ...promo,
        expiryDate: new Date(promo.expiryDate),
    });
    setIsFormDialogOpen(true);
  };
  
  const handleDelete = (promo: Promocode) => {
      setSelectedPromo(promo);
      setIsDeleteDialogOpen(true);
  }
  
  const confirmDelete = () => {
      if (!selectedPromo) return;
      setPromocodes(promocodes.filter(p => p.id !== selectedPromo.id));
      toast({
        title: "Promocode Deleted",
        description: `Code "${selectedPromo.code}" has been removed.`,
        variant: "destructive",
      });
      setIsDeleteDialogOpen(false);
      setSelectedPromo(null);
  }

  const onSubmit = (data: PromocodeFormValues) => {
    if (dialogMode === 'add') {
      const newPromocode: Promocode = {
        id: (Math.max(...promocodes.map(p => parseInt(p.id))) + 1).toString(),
        ...data,
      };
      setPromocodes([...promocodes, newPromocode]);
      toast({
        title: "Promocode Created!",
        description: `Code "${data.code}" has been added successfully.`,
        action: <CheckCircle className="text-green-500" />,
      });
    } else if (selectedPromo) {
        setPromocodes(promocodes.map(p => p.id === selectedPromo.id ? { ...p, ...data } : p));
        toast({
            title: "Promocode Updated!",
            description: `Code "${data.code}" has been updated.`,
            action: <CheckCircle className="text-green-500" />,
        });
    }
    
    setIsFormDialogOpen(false);
    setSelectedPromo(null);
  };

  const formatDiscount = (type: 'percentage' | 'fixed', value: number) => {
    if (type === 'percentage') {
      return `${value}%`;
    }
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold">Promocodes</h1>
        <Button size="sm" className="w-full sm:w-auto" onClick={handleAddNew}>
            <PlusCircle className="h-4 w-4 mr-2" />
            Add Promocode
        </Button>
      </div>
      
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
          <DialogContent className="sm:max-w-[480px]">
            <DialogHeader>
              <DialogTitle>{dialogMode === 'add' ? 'Add New Promocode' : 'Edit Promocode'}</DialogTitle>
              <DialogDescription>
                {dialogMode === 'add'
                  ? "Fill in the details below to add a new promocode."
                  : `Editing promocode: ${selectedPromo?.code}`
                }
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Promocode</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. SUMMER25" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                   <FormField
                    control={form.control}
                    name="discountType"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Discount Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a type" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="percentage">Percentage</SelectItem>
                                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                      control={form.control}
                      name="discountValue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Value</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                </div>
                <FormField
                    control={form.control}
                    name="expiryDate"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Expiry Date</FormLabel>
                        <Popover>
                            <PopoverTrigger asChild>
                            <FormControl>
                                <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                )}
                                >
                                {field.value ? (
                                    format(field.value, "PPP")
                                ) : (
                                    <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                            </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) =>
                                  date < new Date(new Date().setHours(0,0,0,0))
                                }
                                initialFocus
                            />
                            </PopoverContent>
                        </Popover>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select status" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="active">Active</SelectItem>
                                    <SelectItem value="inactive">Inactive</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                    />
                <DialogFooter>
                    <Button type="button" variant="ghost" onClick={() => setIsFormDialogOpen(false)}>Cancel</Button>
                    <Button type="submit">{dialogMode === 'add' ? 'Create Promocode' : 'Save Changes'}</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the
                    <span className="font-bold"> {selectedPromo?.code} </span>
                    promocode.
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">
                    Delete
                </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card>
        <CardHeader>
          <CardTitle>Manage Promocodes</CardTitle>
          <CardDescription>
            View, create, and manage your store's discount codes.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
            {/* Mobile View */}
            <div className="grid gap-4 p-4 md:hidden">
                {promocodes.map((promo) => (
                    <Card key={promo.id}>
                        <CardHeader className="flex flex-row items-start justify-between p-4">
                            <div className="flex-1">
                                <CardTitle className="text-base font-bold">{promo.code}</CardTitle>
                                <CardDescription className="text-sm">{formatDiscount(promo.discountType, promo.discountValue)}</CardDescription>
                            </div>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button aria-haspopup="true" size="icon" variant="ghost">
                                        <MoreHorizontal className="h-4 w-4" />
                                        <span className="sr-only">Toggle menu</span>
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                    <DropdownMenuItem onSelect={() => handleEdit(promo)}>
                                        <Pencil className="mr-2 h-4 w-4" />
                                        Edit
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onSelect={() => handleDelete(promo)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Delete
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </CardHeader>
                        <CardContent className="p-4 pt-0">
                            <Separator className="mb-4" />
                            <div className="flex justify-between items-center text-sm">
                                <Badge variant={promo.status === 'active' ? 'default' : 'secondary'}
                                className={cn(promo.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800')}
                                >
                                {promo.status}
                                </Badge>
                                <span className="text-muted-foreground">Expires: {format(new Date(promo.expiryDate), "dd MMM, yyyy")}</span>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Desktop View */}
            <Table className="hidden md:table">
                <TableHeader>
                <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>
                    <span className="sr-only">Actions</span>
                    </TableHead>
                </TableRow>
                </TableHeader>
                <TableBody>
                {promocodes.map((promo) => (
                    <TableRow key={promo.id}>
                    <TableCell className="font-medium">{promo.code}</TableCell>
                    <TableCell>{formatDiscount(promo.discountType, promo.discountValue)}</TableCell>
                    <TableCell>{format(new Date(promo.expiryDate), "dd MMM, yyyy")}</TableCell>
                    <TableCell>
                        <Badge variant={promo.status === 'active' ? 'default' : 'secondary'}
                        className={cn(promo.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800')}
                        >
                        {promo.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onSelect={() => handleEdit(promo)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onSelect={() => handleDelete(promo)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                    </TableRow>
                ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
