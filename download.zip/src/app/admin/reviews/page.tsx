
"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import Link from 'next/link';
import { products as initialProducts } from "@/lib/data";
import type { Review, QA } from "@/types";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from 'date-fns';

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { MoreHorizontal, Star, Trash2, Check, Send, Pencil } from "lucide-react";

// Local types for aggregated data
type ProductReview = Review & { productName: string; productImage: string; productId: string; };
type ProductQA = QA & { productName: string; productImage: string; productId: string; };

const StarRating = ({ rating, className }: { rating: number, className?: string }) => (
    <div className={cn("flex items-center gap-0.5", className)}>
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={cn(
            "h-4 w-4",
            rating > i ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
          )}
        />
      ))}
    </div>
);

const answerSchema = z.object({
  answer: z.string().min(10, "Answer must be at least 10 characters long."),
});
type AnswerFormValues = z.infer<typeof answerSchema>;

export default function ReviewsPage() {
    const { toast } = useToast();

    const aggregatedData = useMemo(() => {
        const allReviews: ProductReview[] = initialProducts.flatMap(p =>
            p.reviews ? p.reviews.map(r => ({ ...r, productName: p.name, productImage: p.images[0], productId: p.id })) : []
        ).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        const allQA: ProductQA[] = initialProducts.flatMap(p =>
            p.qa ? p.qa.map(q => ({ ...q, productName: p.name, productImage: p.images[0], productId: p.id })) : []
        ).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        return { allReviews, allQA };
    }, []);

    const [reviews, setReviews] = useState<ProductReview[]>(aggregatedData.allReviews);
    const [qa, setQa] = useState<ProductQA[]>(aggregatedData.allQA);

    const [isAnswerDialogOpen, setIsAnswerDialogOpen] = useState(false);
    const [selectedQA, setSelectedQA] = useState<ProductQA | null>(null);

    const form = useForm<AnswerFormValues>({
        resolver: zodResolver(answerSchema),
        defaultValues: { answer: "" },
    });
    
    const handleOpenAnswerDialog = (qaItem: ProductQA) => {
        setSelectedQA(qaItem);
        form.reset({ answer: qaItem.answer || "" });
        setIsAnswerDialogOpen(true);
    };

    const handleDeleteReview = (reviewId: string) => {
        setReviews(prev => prev.filter(r => r.id !== reviewId));
        toast({ title: "Review Deleted", description: "The review has been successfully removed." });
    };

    const handleDeleteQA = (qaId: string) => {
        setQa(prev => prev.filter(q => q.id !== qaId));
        toast({ title: "Q&A Deleted", description: "The question and its answer have been removed." });
    };

    const onAnswerSubmit = (data: AnswerFormValues) => {
        if (!selectedQA) return;
        
        setQa(prev => prev.map(q =>
            q.id === selectedQA.id ? { ...q, answer: data.answer } : q
        ));
        
        toast({
            title: "Answer Submitted!",
            description: "The answer has been posted.",
            action: <Check className="text-green-500" />,
        });
        
        setIsAnswerDialogOpen(false);
        setSelectedQA(null);
    };
    
    return (
        <>
            <Tabs defaultValue="reviews">
                <div className="flex items-center">
                    <TabsList>
                        <TabsTrigger value="reviews">Reviews</TabsTrigger>
                        <TabsTrigger value="qa">Q&A</TabsTrigger>
                    </TabsList>
                </div>
                <TabsContent value="reviews">
                    <Card>
                        <CardHeader>
                            <CardTitle>Customer Reviews</CardTitle>
                            <CardDescription>Manage and view all product reviews submitted by customers.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {reviews.map(review => (
                                <div key={review.id} className="flex gap-4 p-4 border rounded-lg">
                                    <Avatar className="h-12 w-12 rounded-md hidden sm:flex">
                                        <AvatarImage src={review.productImage} alt={review.productName} className="object-cover" />
                                        <AvatarFallback>{review.productName.slice(0, 2)}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <p className="font-semibold">{review.title}</p>
                                                <p className="text-sm text-muted-foreground">
                                                    by <span className="font-medium text-foreground">{review.author}</span> on{' '}
                                                    <Link href={`/product/${review.productId}`} target="_blank" className="font-medium text-primary hover:underline">
                                                        {review.productName}
                                                    </Link>
                                                </p>
                                            </div>
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="icon" className="h-8 w-8">
                                                        <MoreHorizontal className="h-4 w-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => handleDeleteReview(review.id)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                                                    </DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </div>
                                        <div className="flex items-center justify-between mt-2">
                                            <StarRating rating={review.rating} />
                                            <p className="text-xs text-muted-foreground">{format(new Date(review.date), "PPP")}</p>
                                        </div>
                                        <p className="mt-2 text-muted-foreground italic">"{review.text}"</p>
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="qa">
                     <Card>
                        <CardHeader>
                            <CardTitle>Questions & Answers</CardTitle>
                            <CardDescription>Manage and answer customer questions about products.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {qa.map(item => (
                                <div key={item.id} className="p-4 border rounded-lg">
                                    <div className="flex gap-4">
                                        <Avatar className="h-12 w-12 rounded-md hidden sm:flex">
                                            <AvatarImage src={item.productImage} alt={item.productName} className="object-cover" />
                                            <AvatarFallback>{item.productName.slice(0, 2)}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <p className="font-semibold text-muted-foreground">
                                                        Q: <span className="text-foreground">{item.question}</span>
                                                    </p>
                                                    <p className="text-sm text-muted-foreground">
                                                        asked by <span className="font-medium text-foreground">{item.author}</span> for{' '}
                                                        <Link href={`/product/${item.productId}`} target="_blank" className="font-medium text-primary hover:underline">
                                                          {item.productName}
                                                        </Link>
                                                    </p>
                                                </div>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8">
                                                            <MoreHorizontal className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem onClick={() => handleOpenAnswerDialog(item)}>
                                                            <Pencil className="mr-2 h-4 w-4" /> {item.answer ? 'Edit' : 'Answer'}
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem onClick={() => handleDeleteQA(item.id)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </div>
                                        </div>
                                    </div>
                                    {item.answer ? (
                                        <div className="mt-4 pl-4 sm:pl-16 border-l-2 border-primary ml-4 sm:ml-6">
                                            <p className="font-semibold text-primary">A: <span className="text-foreground font-normal">{item.answer}</span></p>
                                            <p className="text-xs text-muted-foreground mt-1">Answered on {format(new Date(), "PPP")}</p>
                                        </div>
                                    ) : (
                                        <div className="mt-4 pl-4 sm:pl-16">
                                            <Button variant="outline" size="sm" onClick={() => handleOpenAnswerDialog(item)}>
                                                <Pencil className="mr-2 h-4 w-4" />
                                                Post an Answer
                                            </Button>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Dialog open={isAnswerDialogOpen} onOpenChange={setIsAnswerDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Post an Answer</DialogTitle>
                        <DialogDescription>
                            Your answer will be publicly visible on the product page.
                        </DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onAnswerSubmit)} className="space-y-4">
                            <div className="text-sm">
                                <p className="font-semibold">{selectedQA?.question}</p>
                                <p className="text-xs text-muted-foreground">For product: {selectedQA?.productName}</p>
                            </div>
                            <FormField
                                control={form.control}
                                name="answer"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Your Answer</FormLabel>
                                        <FormControl>
                                            <Textarea placeholder="Type your answer here..." {...field} rows={5} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <Button type="submit">
                                    <Send className="mr-2 h-4 w-4" />
                                    Post Answer
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>
        </>
    )
}
