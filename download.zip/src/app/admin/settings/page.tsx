
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { format } from "date-fns";
import JSZip from 'jszip';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Package, ShoppingCart, Users, Ticket, FileSpreadsheet, FileText, Archive } from "lucide-react";

import { products, orders } from '@/lib/data';
import { customers, promocodes } from '@/lib/admin-data';

// Extend jsPDF with autoTable
interface jsPDFWithAutoTable extends jsPDF {
  autoTable: (options: any) => jsPDF;
}

const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', currencyDisplay: 'code' }).format(price);
};

const formatDate = (date: Date) => {
    return date.toLocaleString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Kolkata'
    });
};

const appearanceSchema = z.object({
    primaryColor: z.string().regex(/^#[0-9a-f]{6}$/i, "Invalid hex color format. e.g., #249760"),
    secondaryColor: z.string().regex(/^#[0-9a-f]{6}$/i, "Invalid hex color format. e.g., #f0f5fc"),
    accentColor: z.string().regex(/^#[0-9a-f]{6}$/i, "Invalid hex color format. e.g., #32b86c"),
});

type AppearanceValues = z.infer<typeof appearanceSchema>;

export default function SettingsPage() {
    const { toast } = useToast();

    const appearanceForm = useForm<AppearanceValues>({
        resolver: zodResolver(appearanceSchema),
        defaultValues: {
          primaryColor: '#249760',
          secondaryColor: '#f0f5fc',
          accentColor: '#32b86c',
        },
    });

    function onAppearanceSubmit(data: AppearanceValues) {
        console.log(data);
        toast({
            title: "Appearance Settings Updated",
            description: "Your theme colors have been saved. Changes will apply on next refresh.",
            action: <CheckCircle className="text-green-500" />,
        });
    }

    const generateCSVString = (headers: string[], rows: (string|number)[][]): string => {
      return [
          headers.join(','),
          ...rows.map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
      ].join('\n');
    };

    const triggerDownload = (content: string | Blob, filename: string, type: string) => {
        const blob = content instanceof Blob ? content : new Blob([content], { type });
        const link = document.createElement("a");
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", filename);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };
    
    // --- CSV Handlers ---
    const handleExportProductsCSV = () => {
        const headers = ["Product ID", "Name", "Description", "Category", "Price", "Stock", "Image URL"];
        const rows = products.map(p => [p.id, p.name, p.description, p.category, p.price, p.stock, p.images[0]]);
        triggerDownload(generateCSVString(headers, rows), 'products.csv', 'text/csv;charset=utf-8;');
    };
    const handleExportOrdersCSV = () => {
        const headers = ["Order ID", "Customer Name", "Customer Email", "Date", "Status", "Total", "Items", "Shipping Name", "Address Line 1", "Address Line 2", "City", "State", "ZIP", "Country"];
        const rows = orders.map(o => {
            const itemsString = o.items.map(item => `${item.name} (Qty: ${item.quantity}, Price: ${item.price})`).join('; ');
            return [o.id, o.customerName, o.customerEmail, formatDate(o.date), o.status, o.total, itemsString, o.shippingAddress.name, o.shippingAddress.addressLine1, o.shippingAddress.addressLine2 || '', o.shippingAddress.city, o.shippingAddress.state, o.shippingAddress.zip, o.shippingAddress.country];
        });
        triggerDownload(generateCSVString(headers, rows), 'orders.csv', 'text/csv;charset=utf-8;');
    };
    const handleExportCustomersCSV = () => {
        const headers = ["Customer ID", "Name", "Email", "Total Spent"];
        const rows = customers.map(c => [c.id, c.name, c.email, c.totalSpent]);
        triggerDownload(generateCSVString(headers, rows), 'customers.csv', 'text/csv;charset=utf-8;');
    };
    const handleExportPromocodesCSV = () => {
        const headers = ["Code", "Discount Type", "Value", "Expiry Date", "Status"];
        const rows = promocodes.map(p => [p.code, p.discountType, p.discountValue, format(p.expiryDate, "yyyy-MM-dd"), p.status]);
        triggerDownload(generateCSVString(headers, rows), 'promocodes.csv', 'text/csv;charset=utf-8;');
    };

    // --- PDF Handlers ---
    const createPdfReport = (title: string, head: any[], body: any[][], filename: string) => {
        const doc = new jsPDF() as jsPDFWithAutoTable;
        doc.setFontSize(18);
        doc.text(title, 14, 22);
        doc.autoTable({ head, body, startY: 30, theme: 'grid' });
        doc.save(filename);
    }
    const handleExportProductsPDF = () => createPdfReport('Products Report', [["ID", "Name", "Category", "Stock", "Price"]], products.map(p => [p.id, p.name, p.category, p.stock, formatPrice(p.price)]), 'products-report.pdf');
    const handleExportOrdersPDF = () => createPdfReport('Orders Report', [["ID", "Customer", "Date", "Status", "Total"]], orders.map(o => [o.id, o.customerName, format(o.date, "dd-MM-yyyy"), o.status, formatPrice(o.total)]), 'orders-report.pdf');
    const handleExportCustomersPDF = () => createPdfReport('Customers Report', [["ID", "Name", "Email", "Total Spent"]], customers.map(c => [c.id, c.name, c.email, formatPrice(c.totalSpent)]), 'customers-report.pdf');
    const handleExportPromocodesPDF = () => createPdfReport('Promocodes Report', [["Code", "Discount", "Expires", "Status"]], promocodes.map(p => [p.code, p.discountType === 'fixed' ? formatPrice(p.discountValue) : `${p.discountValue}%`, format(p.expiryDate, "dd MMM, yyyy"), p.status]), 'promocodes-report.pdf');
    
    // --- All Data Handlers ---
    const handleExportAllPDF = () => {
        const doc = new jsPDF() as jsPDFWithAutoTable;
        const addPage = (title: string, head: any[], body: any[][], docInstance: jsPDFWithAutoTable) => {
          docInstance.addPage();
          docInstance.setFontSize(18);
          docInstance.text(title, 14, 22);
          docInstance.autoTable({ head, body, startY: 30, theme: 'grid' });
        };

        doc.setFontSize(22);
        doc.setFont("helvetica", "bold");
        doc.text("Rose Bloom Boutique - Full Data Export", doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Export Date: ${format(new Date(), 'PPP')}`, doc.internal.pageSize.getWidth() / 2, 30, { align: 'center' });

        doc.autoTable({
          head: [["ID", "Name", "Category", "Stock", "Price"]],
          body: products.map(p => [p.id, p.name, p.category, p.stock, formatPrice(p.price)]),
          startY: 40,
          theme: 'grid',
          didDrawPage: (data) => {
            doc.setFontSize(18);
            doc.text('Products Report', 14, data.settings.margin.top);
          }
        });
        
        addPage('Orders Report', [["ID", "Customer", "Date", "Status", "Total"]], orders.map(o => [o.id, o.customerName, format(o.date, "dd-MM-yyyy"), o.status, formatPrice(o.total)]), doc);
        addPage('Customers Report', [["ID", "Name", "Email", "Total Spent"]], customers.map(c => [c.id, c.name, c.email, formatPrice(c.totalSpent)]), doc);
        addPage('Promocodes Report', [["Code", "Discount", "Expires", "Status"]], promocodes.map(p => [p.code, p.discountType === 'fixed' ? formatPrice(p.discountValue) : `${p.discountValue}%`, format(p.expiryDate, "dd MMM, yyyy"), p.status]), doc);
        
        doc.deletePage(1); // Delete the initial blank page
        doc.save(`full-site-report_${new Date().toISOString().slice(0,10)}.pdf`);
    };

    const handleExportAllCSV = async () => {
        const zip = new JSZip();
        // Products
        const productHeaders = ["Product ID", "Name", "Description", "Category", "Price", "Stock", "Image URL"];
        const productRows = products.map(p => [p.id, p.name, p.description, p.category, p.price, p.stock, p.images[0]]);
        zip.file("products.csv", generateCSVString(productHeaders, productRows));
        // Orders
        const orderHeaders = ["Order ID", "Customer Name", "Customer Email", "Date", "Status", "Total", "Items", "Shipping Name", "Address Line 1", "Address Line 2", "City", "State", "ZIP", "Country"];
        const orderRows = orders.map(o => {
            const itemsString = o.items.map(item => `${item.name} (Qty: ${item.quantity}, Price: ${item.price})`).join('; ');
            return [o.id, o.customerName, o.customerEmail, formatDate(o.date), o.status, o.total, itemsString, o.shippingAddress.name, o.shippingAddress.addressLine1, o.shippingAddress.addressLine2 || '', o.shippingAddress.city, o.shippingAddress.state, o.shippingAddress.zip, o.shippingAddress.country];
        });
        zip.file("orders.csv", generateCSVString(orderHeaders, orderRows));
        // Customers
        const customerHeaders = ["Customer ID", "Name", "Email", "Total Spent"];
        const customerRows = customers.map(c => [c.id, c.name, c.email, c.totalSpent]);
        zip.file("customers.csv", generateCSVString(customerHeaders, customerRows));
        // Promocodes
        const promocodeHeaders = ["Code", "Discount Type", "Value", "Expiry Date", "Status"];
        const promocodeRows = promocodes.map(p => [p.code, p.discountType, p.discountValue, format(p.expiryDate, "yyyy-MM-dd"), p.status]);
        zip.file("promocodes.csv", generateCSVString(promocodeHeaders, promocodeRows));

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        triggerDownload(zipBlob, `full-site-export_${new Date().toISOString().slice(0,10)}.zip`, 'application/zip');
    }
    
    const exportItems = [
      { title: 'Products', description: 'All products in your store.', icon: Package, onCSV: handleExportProductsCSV, onPDF: handleExportProductsPDF },
      { title: 'Orders', description: 'A complete history of all orders.', icon: ShoppingCart, onCSV: handleExportOrdersCSV, onPDF: handleExportOrdersPDF },
      { title: 'Customers', description: 'Your entire customer list.', icon: Users, onCSV: handleExportCustomersCSV, onPDF: handleExportCustomersPDF },
      { title: 'Promocodes', description: 'All active and inactive promocodes.', icon: Ticket, onCSV: handleExportPromocodesCSV, onPDF: handleExportPromocodesPDF },
    ];

    return (
        <div className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle>Appearance</CardTitle>
                    <CardDescription>Customize the look and feel of your store.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Form {...appearanceForm}>
                        <form onSubmit={appearanceForm.handleSubmit(onAppearanceSubmit)} className="space-y-6">
                            <FormField
                                control={appearanceForm.control}
                                name="primaryColor"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Primary Color</FormLabel>
                                        <FormControl>
                                            <div className="flex items-center gap-2">
                                                <label
                                                    htmlFor="primary-color"
                                                    style={{ backgroundColor: field.value }}
                                                    className="h-10 w-10 rounded-md border cursor-pointer"
                                                />
                                                <input
                                                    id="primary-color"
                                                    type="color"
                                                    className="sr-only"
                                                    value={field.value}
                                                    onChange={(e) => field.onChange(e.target.value)}
                                                />
                                                <Input
                                                    {...field}
                                                    className="flex-1"
                                                    placeholder="#249760"
                                                />
                                            </div>
                                        </FormControl>
                                        <FormDescription>
                                            The main brand color for buttons and highlights. Click the swatch to pick a color.
                                        </FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={appearanceForm.control}
                                name="secondaryColor"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Secondary Color</FormLabel>
                                        <FormControl>
                                            <div className="flex items-center gap-2">
                                                <label
                                                    htmlFor="secondary-color"
                                                    style={{ backgroundColor: field.value }}
                                                    className="h-10 w-10 rounded-md border cursor-pointer"
                                                />
                                                <input
                                                    id="secondary-color"
                                                    type="color"
                                                    className="sr-only"
                                                    value={field.value}
                                                    onChange={(e) => field.onChange(e.target.value)}
                                                />
                                                <Input
                                                    {...field}
                                                    className="flex-1"
                                                    placeholder="#f0f5fc"
                                                />
                                            </div>
                                        </FormControl>
                                        <FormDescription>
                                            Used for card backgrounds and section dividers.
                                        </FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={appearanceForm.control}
                                name="accentColor"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Accent Color</FormLabel>
                                        <FormControl>
                                             <div className="flex items-center gap-2">
                                                <label
                                                    htmlFor="accent-color"
                                                    style={{ backgroundColor: field.value }}
                                                    className="h-10 w-10 rounded-md border cursor-pointer"
                                                />
                                                <input
                                                    id="accent-color"
                                                    type="color"
                                                    className="sr-only"
                                                    value={field.value}
                                                    onChange={(e) => field.onChange(e.target.value)}
                                                />
                                                <Input
                                                    {...field}
                                                    className="flex-1"
                                                    placeholder="#32b86c"
                                                />
                                            </div>
                                        </FormControl>
                                        <FormDescription>
                                            An alternative color for highlights and call-to-actions.
                                        </FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <div className="flex justify-end">
                                 <Button type="submit">Save Appearance</Button>
                            </div>
                        </form>
                    </Form>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Export Data</CardTitle>
                    <CardDescription>Download your store's data in various formats.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    {exportItems.map((item, index) => (
                      <div key={item.title}>
                        <div className="flex items-start sm:items-center gap-4 flex-col sm:flex-row">
                          <item.icon className="h-8 w-8 text-muted-foreground flex-shrink-0" />
                          <div className="flex-1">
                            <h3 className="font-semibold">{item.title}</h3>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                          <div className="flex gap-2 ml-auto flex-shrink-0">
                            <Button variant="outline" size="sm" onClick={item.onCSV}>
                              <FileSpreadsheet className="mr-2 h-4 w-4" />
                              CSV
                            </Button>
                            <Button variant="outline" size="sm" onClick={item.onPDF}>
                              <FileText className="mr-2 h-4 w-4" />
                              PDF
                            </Button>
                          </div>
                        </div>
                        {index < exportItems.length - 1 && <Separator className="mt-4" />}
                      </div>
                    ))}
                  </div>
                  <Separator />
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 rounded-lg border p-4">
                      <div className="flex-1">
                        <h3 className="font-semibold">Export All Data</h3>
                        <p className="text-sm text-muted-foreground">Download a complete backup of your store's data.</p>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto sm:ml-auto flex-shrink-0">
                          <Button variant="secondary" onClick={handleExportAllCSV} className="w-full sm:w-auto">
                            <Archive className="mr-2 h-4 w-4" />
                            Export All (ZIP)
                          </Button>
                          <Button onClick={handleExportAllPDF} className="w-full sm:w-auto">
                            <FileText className="mr-2 h-4 w-4" />
                            Export All (PDF)
                          </Button>
                      </div>
                  </div>
                </CardContent>
            </Card>
        </div>
    );
}
