
"use client";

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useCart } from '@/hooks/use-cart';
import { products } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, ShoppingBag } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';
import { ProductCard } from '@/components/product-card';

export default function CartPage() {
  const { cartItems, removeFromCart, updateQuantity, subtotal, gst, deliveryFee, discount, cartTotal, cartCount, applyPromoCode } = useCart();
  const [promoCodeInput, setPromoCodeInput] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(price);
  };
  
  if (cartCount === 0) {
    return (
        <div className="container px-4 sm:px-6 my-8 md:my-12">
            <div className="flex flex-col items-center justify-center text-center py-24 px-4 sm:px-6 border-2 border-dashed rounded-lg">
                <ShoppingBag className="mx-auto h-24 w-24 text-muted-foreground" />
                <h1 className="mt-8 text-3xl font-headline font-bold">Your Cart is Empty</h1>
                <p className="mt-4 text-muted-foreground">Looks like you haven't added anything to your cart yet.</p>
                <Button asChild className="mt-8">
                    <Link href="/collections">Continue Shopping</Link>
                </Button>
            </div>
            <section className="mt-16">
              <h2 className="text-2xl font-bold font-headline mb-6 text-center">You Might Also Like</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-10">
                  {products.slice(-4).map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </section>
        </div>
    );
  }

  return (
    <div className="container px-4 sm:px-6 my-8 md:my-12">
        <div className="text-center mb-8 md:mb-12">
            <h1 className="text-4xl font-headline font-bold">Shopping Cart</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 xl:gap-12 items-start">
            <div className="lg:col-span-2 space-y-12">
                <Card>
                    <CardContent className="p-0 divide-y divide-border">
                        {cartItems.map(item => {
                            const cartItemId = `${item.id}-${item.selectedSize}-${item.selectedColor}`;
                            return (
                                <div key={cartItemId} className="p-4 md:p-6">
                                    <div className="flex flex-col sm:flex-row gap-4">
                                        <div className="relative h-24 w-24 sm:h-32 sm:w-32 rounded-md overflow-hidden flex-shrink-0 bg-secondary mx-auto sm:mx-0">
                                            <Image src={item.images[0]} alt={item.name} fill className="object-cover" />
                                        </div>
                        
                                        <div className="flex-1 min-w-0 flex flex-col justify-center">
                                            <div className="flex justify-between items-start gap-4">
                                                <div className="flex-1 min-w-0">
                                                    <Link href={`/product/${item.id}`} className="font-semibold hover:text-primary break-words">{item.name}</Link>
                                                    <p className="text-sm text-muted-foreground mt-1">
                                                        Size: {item.selectedSize} / Color: {item.selectedColor}
                                                    </p>
                                                </div>
                                                <Button variant="ghost" size="icon" className="-mr-2 -mt-2 flex-shrink-0" onClick={() => removeFromCart(cartItemId)}>
                                                    <X className="h-5 w-5 text-muted-foreground" />
                                                </Button>
                                            </div>
                                            <div className="flex justify-between items-end mt-4">
                                                 <p className="font-semibold text-lg">{formatPrice(item.price * item.quantity)}</p>
                                                 <Input 
                                                    type="number" 
                                                    min="1"
                                                    value={item.quantity}
                                                    onChange={(e) => updateQuantity(cartItemId, parseInt(e.target.value, 10))}
                                                    className="w-20 text-center"
                                                    aria-label="Quantity"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </CardContent>
                </Card>
                
                <section>
                    <h2 className="text-2xl font-bold font-headline mb-6">You Might Also Like</h2>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
                        {products.filter(p => !cartItems.some(item => item.id === p.id)).slice(-3).map(product => (
                            <ProductCard key={product.id} product={product} />
                        ))}
                    </div>
                </section>
            </div>

            <div className="lg:col-span-1 bg-secondary rounded-lg p-6 h-fit lg:sticky lg:top-24">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="flex gap-2 mb-4">
                  <Input 
                    placeholder="Promo Code" 
                    value={promoCodeInput}
                    onChange={(e) => setPromoCodeInput(e.target.value)}
                  />
                  <Button onClick={() => applyPromoCode(promoCodeInput)} disabled={!promoCodeInput}>Apply</Button>
                </div>
                <Separator className="mb-4 bg-border/50" />
                <div className="space-y-2">
                    <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>{formatPrice(subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>GST (18%)</span>
                        <span>{formatPrice(gst)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                        <span>Delivery Charges</span>
                        <span>{deliveryFee > 0 ? formatPrice(deliveryFee) : 'Free'}</span>
                    </div>
                    {discount > 0 && (
                       <div className="flex justify-between text-green-600 font-medium">
                        <span>Discount</span>
                        <span>-{formatPrice(discount)}</span>
                      </div>
                    )}
                </div>
                <Separator className="my-4 bg-border/50" />
                <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>{formatPrice(cartTotal)}</span>
                </div>
                <Button size="lg" className="w-full mt-6">
                    Proceed to Checkout
                </Button>
            </div>
        </div>
    </div>
  );
}
