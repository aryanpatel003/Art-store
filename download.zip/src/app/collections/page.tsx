
"use client";

import { useState, useMemo, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { products } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { CollectionControls } from '@/components/collection-controls';
import { ProductCardSkeleton } from '@/components/product-card-skeleton';

export type Filters = {
  categories: string[];
  colors: string[];
  priceRange: [number, number];
};

function CollectionsContent() {
  const searchParams = useSearchParams();
  const initialSort = searchParams.get('sort') || 'newest';

  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState<Filters>({
    categories: [],
    colors: [],
    priceRange: [0, 200], // Default range
  });
  const [sortOption, setSortOption] = useState(initialSort);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000); // 1 second delay
    return () => clearTimeout(timer);
  }, []);

  // Sync state if URL search param changes
  useEffect(() => {
    const sort = searchParams.get('sort');
    if (sort) {
      setSortOption(sort);
    }
  }, [searchParams]);

  const { allCategories, allColors, maxPrice } = useMemo(() => {
    const categories = [...new Set(products.map(p => p.category))];
    const colors = [...new Set(products.flatMap(p => p.colors))];
    const price = Math.max(...products.map(p => p.price));
    return { allCategories: categories, allColors: colors, maxPrice: price };
  }, []);

  useEffect(() => {
    // Set initial price range once maxPrice is calculated
    setFilters(prev => ({ ...prev, priceRange: [0, Math.ceil(maxPrice / 10) * 10] }));
  }, [maxPrice]);

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = products.filter(product => {
      const inCategory = filters.categories.length === 0 || filters.categories.includes(product.category);
      const hasColor = filters.colors.length === 0 || product.colors.some(c => filters.colors.includes(c));
      const inPriceRange = product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1];
      return inCategory && hasColor && inPriceRange;
    });

    return [...filtered].sort((a, b) => {
      switch (sortOption) {
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'newest':
        default:
          return 0; // Maintain original order
      }
    });
  }, [filters, sortOption]);

  return (
    <div className="grid lg:grid-cols-4 gap-8">
      <aside className="lg:col-span-1">
        <CollectionControls
          filters={filters}
          setFilters={setFilters}
          sortOption={sortOption}
          setSortOption={setSortOption}
          allCategories={allCategories}
          allColors={allColors}
          maxPrice={maxPrice}
          productCount={filteredAndSortedProducts.length}
        />
      </aside>
      <main className="lg:col-span-3">
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
            {Array.from({ length: 9 }).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : filteredAndSortedProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
            {filteredAndSortedProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full min-h-[40vh] bg-secondary rounded-lg">
            <div className="text-center p-8">
              <h2 className="text-2xl font-semibold">No Products Found</h2>
              <p className="mt-2 text-muted-foreground">Try adjusting your filters to find what you're looking for.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

export default function CollectionsPage() {
  return (
    <div className="container px-4 sm:px-6 my-8 md:my-12">
      <div className="text-center mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">All Products</h1>
        <p className="mt-2 text-lg text-muted-foreground">Find the perfect tools for your next masterpiece.</p>
      </div>
      <Suspense fallback={<CollectionsSkeleton />}>
        <CollectionsContent />
      </Suspense>
    </div>
  );
}


function CollectionsSkeleton() {
  return (
     <div className="grid lg:grid-cols-4 gap-8">
      <aside className="lg:col-span-1">
        {/* Simplified controls skeleton */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
             <div className="h-6 bg-muted rounded w-24 animate-pulse" />
             <div className="h-9 bg-muted rounded w-[180px] animate-pulse" />
          </div>
          <div className="space-y-4">
             <div className="h-12 bg-muted rounded animate-pulse" />
             <div className="h-12 bg-muted rounded animate-pulse" />
             <div className="h-12 bg-muted rounded animate-pulse" />
          </div>
        </div>
      </aside>
      <main className="lg:col-span-3">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
            {Array.from({ length: 9 }).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
      </main>
    </div>
  )
}
