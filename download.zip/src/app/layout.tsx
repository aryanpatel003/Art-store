
import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Poppins, Playfair_Display } from 'next/font/google';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { CartProvider } from '@/hooks/cart-provider';
import { WishlistProvider } from '@/hooks/wishlist-provider';
import { ConditionalHeader } from '@/components/conditional-header';
import { ConditionalFooter } from '@/components/conditional-footer';
import { ConditionalMobileNav } from '@/components/conditional-mobile-nav';
import { cn } from '@/lib/utils';
import { MainLayout } from '@/components/main-layout';


export const metadata: Metadata = {
  title: 'Canvas & Palette',
  description: 'High-quality art supplies for every creator.',
};

const poppins = Poppins({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-poppins',
  weight: ['400', '600']
});

const playfairDisplay = Playfair_Display({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-playfair-display',
  weight: '700'
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={cn("h-full", poppins.variable, playfairDisplay.variable)}>
      <head />
      <body className="font-body antialiased flex flex-col min-h-screen bg-background text-foreground">
        <CartProvider>
          <WishlistProvider>
            <ConditionalHeader />
            <MainLayout>{children}</MainLayout>
            <ConditionalFooter />
            <ConditionalMobileNav />
            <Toaster />
            <Suspense fallback={null}>
            </Suspense>
          </WishlistProvider>
        </CartProvider>
      </body>
    </html>
  );
}
