
import Image from 'next/image';
import { orders } from '@/lib/data';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package } from 'lucide-react';
import { cn } from '@/lib/utils';

const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(price);
};

const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });
}

export default function OrdersPage() {
    if (!orders || orders.length === 0) {
        return (
            <div className="container text-center py-24 px-4 sm:px-6">
                <Package className="mx-auto h-24 w-24 text-muted-foreground" />
                <h1 className="mt-8 text-3xl font-headline font-bold">No Orders Yet</h1>
                <p className="mt-4 text-muted-foreground">You haven't placed any orders with us yet.</p>
            </div>
        );
    }
    
  return (
    <div className="container max-w-4xl mx-auto my-8 md:my-12 px-4 sm:px-6">
      <div className="text-center mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">My Orders</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          View your order history and track current shipments.
        </p>
      </div>

      <Accordion type="single" collapsible className="w-full space-y-4">
        {orders.map((order) => (
          <AccordionItem value={`item-${order.id}`} key={order.id} className="bg-secondary/50 border-border rounded-lg">
            <AccordionTrigger className="p-4 md:p-6 hover:no-underline">
              <div className="flex flex-col md:flex-row md:items-center justify-between w-full text-left gap-2">
                <div className="flex-1">
                  <p className="font-semibold text-base">Order #{order.id}</p>
                  <p className="text-sm text-muted-foreground">
                    Date: {formatDate(order.date)}
                  </p>
                </div>
                <div className="flex items-center gap-4 md:gap-8">
                   <Badge
                    variant={order.status === 'Delivered' ? 'default' : 'secondary'}
                    className={cn(
                      order.status === 'Shipped' && 'bg-blue-100 text-blue-800',
                      order.status === 'Processing' && 'bg-yellow-100 text-yellow-800',
                      order.status === 'Delivered' && 'bg-green-100 text-green-800'
                    )}
                  >
                    {order.status}
                  </Badge>
                  <p className="font-semibold text-base w-24 text-right">{formatPrice(order.total)}</p>
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent className="p-4 md:p-6 pt-0">
              <Separator className="mb-4 bg-border/80" />
              <div className="space-y-4">
                {order.items.map(item => (
                    <div key={item.id} className="flex items-start gap-4">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden bg-white flex-shrink-0">
                            <Image
                                src={item.image}
                                alt={item.name}
                                fill
                                className="object-contain p-1"
                            />
                        </div>
                        <div className="flex-1">
                            <p className="font-medium">{item.name}</p>
                            <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                        </div>
                        <p className="text-sm font-medium">{formatPrice(item.price)}</p>
                    </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
