
"use client";

import { useRef } from 'react';
import { products, bannerItems } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { Award, Leaf, Truck, Star, ShieldCheck, Undo2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';

const categories = [
    { name: 'Paints', image: 'https://placehold.co/100x100.png', hint: 'paint tubes' },
    { name: 'Drawing', image: 'https://placehold.co/100x100.png', hint: 'pencils' },
    { name: 'Canvas', image: 'https://placehold.co/100x100.png', hint: 'stretched canvas' },
    { name: 'Brushes', image: 'https://placehold.co/100x100.png', hint: 'paint brushes' },
    { name: 'Easels', image: 'https://placehold.co/100x100.png', hint: 'art easel' },
    { name: 'Mediums', image: 'https://placehold.co/100x100.png', hint: 'gesso jar' },
];

const testimonials = [
  {
    id: 'r1',
    author: 'Emily R.',
    rating: 5,
    text: "The vibrancy of these watercolors is unmatched. They blend beautifully and the tin case is perfect for travel. Highly recommend!",
    productName: 'Professional Watercolor Set'
  },
  {
    id: 'r5',
    author: 'CanvasQueen',
    rating: 5,
    text: 'These acrylics are a dream to work with. The colors are so rich and they have a lovely buttery consistency. Perfect for professional work.',
    productName: 'Artist Acrylic Paint Set'
  },
  {
    id: 'r4',
    author: 'SketchMaster',
    rating: 5,
    text: 'The paper holds up so well to ink and light watercolor washes. No bleeding at all. The cover is sturdy and feels great. Will buy again.',
    productName: 'Heavyweight Sketchbook Trio'
  }
];

export default function Home() {
  const plugin = useRef(
    Autoplay({ delay: 5000, stopOnInteraction: true })
  );

  return (
    <div>
      <Carousel
        plugins={[plugin.current]}
        className="w-full"
        onMouseEnter={plugin.current.stop}
        onMouseLeave={plugin.current.reset}
      >
        <CarouselContent>
          {bannerItems.map((banner, index) => (
            <CarouselItem key={index}>
              <div className="relative w-full h-[60vh] md:h-[70vh] overflow-hidden">
                <Image
                    src={banner.image}
                    alt={banner.alt}
                    fill
                    className="object-cover"
                    data-ai-hint={banner.hint}
                    priority={index === 0}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/20" />
                <div className="absolute inset-0 container mx-auto px-4 sm:px-6 flex flex-col justify-center">
                    <div className="max-w-lg text-white">
                        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold font-headline">{banner.title}</h1>
                        <p className="mt-4 text-base md:text-lg">{banner.description}</p>
                        <Button asChild size="lg" className="mt-6 bg-accent text-accent-foreground hover:bg-accent/90">
                            <Link href={banner.buttonLink}>{banner.buttonText}</Link>
                        </Button>
                    </div>
                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
      
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold font-headline">Categories</h2>
            <Link href="/collections" className="text-sm font-semibold text-primary hover:underline">See all</Link>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
              {categories.map(category => (
                  <Link href="/collections" key={category.name} className="flex flex-col items-center gap-2 group">
                      <div className="w-16 h-16 sm:w-20 sm:h-20 bg-secondary rounded-2xl overflow-hidden transition-all group-hover:scale-105">
                          <Image src={category.image} alt={category.name} width={100} height={100} className="object-cover w-full h-full" data-ai-hint={category.hint} />
                      </div>
                      <span className="text-sm font-medium text-center group-hover:text-primary">{category.name}</span>
                  </Link>
              ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-secondary">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold font-headline">Bestsellers</h2>
            <p className="mt-2 text-muted-foreground">Our most popular and highly-rated products.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-10">
              {products.slice(0, 4).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
          <div className="text-center mt-10">
            <Button asChild>
                <Link href="/collections">Shop All Bestsellers</Link>
            </Button>
          </div>
        </div>
      </section>
      
      <section className="py-12 md:py-20">
          <div className="container mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold font-headline">Why Canvas & Palette?</h2>
              <p className="mt-2 text-muted-foreground">Your trusted partner in creativity.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center max-w-4xl mx-auto">
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                  <Award className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold">Trusted by 10k+ Artists</h3>
                <p className="mt-2 text-muted-foreground">Join a community of creators who rely on our quality supplies.</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                  <Leaf className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold">Eco-Friendly Options</h3>
                <p className="mt-2 text-muted-foreground">We are committed to providing sustainable art materials.</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-4">
                  <Truck className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold">Fast & Reliable Shipping</h3>
                <p className="mt-2 text-muted-foreground">Get your supplies quickly, so you can start creating sooner.</p>
              </div>
            </div>
          </div>
      </section>
      
      <section className="py-12 md:py-16 bg-secondary">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold font-headline">New Arrivals</h2>
            <p className="mt-2 text-muted-foreground">Check out the latest additions to our collection.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-10">
              {products.slice(4, 8).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-20">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-headline">From Our Customers</h2>
            <p className="mt-2 text-muted-foreground">Hear what fellow artists are saying about their favorite supplies.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map(review => (
              <Card key={review.id}>
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground italic">"{review.text}"</p>
                  <div className="flex items-center mt-4">
                    <Avatar className="h-10 w-10 mr-4">
                        <AvatarImage src={`https://placehold.co/40x40.png`} alt={review.author} data-ai-hint="person face" />
                        <AvatarFallback>{review.author.split(' ').map(n=>n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{review.author}</p>
                      <p className="text-sm text-muted-foreground">Verified Buyer</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-primary/5">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold font-headline">Limited Editions</h2>
            <p className="mt-2 text-muted-foreground">Exclusive supplies, available for a short time only. Don't miss out!</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-10">
            {products.slice(2, 6).map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

       <section className="border-t">
        <div className="container mx-auto px-4 sm:px-6">
           <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center py-8">
              <div className="flex items-center justify-center gap-4">
                <Truck className="h-8 w-8 text-primary" />
                <div>
                  <h4 className="font-semibold">Free Shipping</h4>
                  <p className="text-sm text-muted-foreground">On orders over ₹4000</p>
                </div>
              </div>
              <div className="flex items-center justify-center gap-4">
                <Undo2 className="h-8 w-8 text-primary" />
                <div>
                  <h4 className="font-semibold">Easy Returns</h4>
                  <p className="text-sm text-muted-foreground">30-day return policy</p>
                </div>
              </div>
              <div className="flex items-center justify-center gap-4">
                <ShieldCheck className="h-8 w-8 text-primary" />
                <div>
                  <h4 className="font-semibold">Secure Payments</h4>
                  <p className="text-sm text-muted-foreground">100% secure checkout</p>
                </div>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
}
