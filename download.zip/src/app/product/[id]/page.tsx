
"use client";

import { useState, useEffect } from 'react';
import { notFound, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useForm } from "react-hook-form";

import { products } from '@/lib/data';
import { useCart } from '@/hooks/use-cart';
import { useToast } from '@/hooks/use-toast';
import { useWishlist } from '@/hooks/use-wishlist';
import { cn } from '@/lib/utils';
import type { Review, QA } from '@/types';

import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, type CarouselApi } from "@/components/ui/carousel";
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

import { Heart, ShoppingBag, CheckCircle, Star, FileText, MessageCircle, ArrowLeft, ShieldCheck, HelpCircle } from 'lucide-react';


const StarRating = ({ rating, count, className }: { rating: number, count?: number, className?: string }) => {
  return (
    <div className={cn("flex items-center gap-1", className)}>
      <div className="flex items-center gap-0.5">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={cn(
              "h-5 w-5",
              rating > i ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
            )}
          />
        ))}
      </div>
      {count !== undefined && <span className="text-sm text-muted-foreground">({count})</span>}
    </div>
  )
}

const reviewFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  rating: z.number().min(1, "Please select a rating.").max(5),
  title: z.string().min(4, "Title must be at least 4 characters."),
  text: z.string().min(10, "Review must be at least 10 characters."),
});
type ReviewFormValues = z.infer<typeof reviewFormSchema>;

const qaFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  question: z.string().min(10, "Question must be at least 10 characters."),
});
type QAFormValues = z.infer<typeof qaFormSchema>;


export default function ProductPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { toast } = useToast();
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const product = products.find(p => p.id === params.id);
  
  const [selectedSize, setSelectedSize] = useState<string | undefined>(product?.sizes.length === 1 ? product.sizes[0] : undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(product?.colors.length === 1 ? product.colors[0] : undefined);
  
  const [api, setApi] = useState<CarouselApi>()
  const [current, setCurrent] = useState(0)

  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const [isQAOpen, setIsQAOpen] = useState(false);
  
  // States for star rating input
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
 
  useEffect(() => {
    if (!api) {
      return
    }
    setCurrent(api.selectedScrollSnap())
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap())
    })
  }, [api])

  const reviewForm = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: { name: "", rating: 0, title: "", text: "" },
  });

  const qaForm = useForm<QAFormValues>({
    resolver: zodResolver(qaFormSchema),
    defaultValues: { name: "", question: "" },
  });

  const onReviewSubmit = (data: ReviewFormValues) => {
    console.log("New Review Submitted:", data);
    toast({
      title: "Review Submitted!",
      description: "Thank you for your feedback.",
      action: <CheckCircle className="text-green-500" />,
    });
    reviewForm.reset();
    setRating(0);
    setIsReviewOpen(false);
  };

  const onQASubmit = (data: QAFormValues) => {
    console.log("New Question Submitted:", data);
    toast({
      title: "Question Submitted!",
      description: "We'll answer your question shortly.",
      action: <CheckCircle className="text-green-500" />,
    });
    qaForm.reset();
    setIsQAOpen(false);
  };

  const handleThumbnailClick = (index: number) => {
    api?.scrollTo(index);
  }

  if (!product) {
    notFound();
  }
  
  const isLiked = isInWishlist(product.id);

  const reviews = product?.reviews || [];
  const qa = product?.qa || [];
  const averageRating = reviews.length > 0 ? reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length : 0;
  
  const handleAddToCart = () => {
    if (product.sizes.length > 1 && !selectedSize) {
        toast({ title: "Please select a size.", variant: "destructive" });
        return;
    }
    if (product.colors.length > 1 && !selectedColor) {
        toast({ title: "Please select a color.", variant: "destructive" });
        return;
    }
    addToCart(product, selectedSize || product.sizes[0], selectedColor || product.colors[0]);
    toast({
      title: "Added to Cart!",
      description: `${product.name} has been added to your cart.`,
      action: <CheckCircle className="text-green-500" />,
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
      });
  }

  return (
    <>
      <div className="container mx-auto max-w-6xl my-4 md:my-12 pb-24 md:pb-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16">
            {/* Image Gallery */}
            <div className="relative space-y-4 md:sticky md:top-24 h-fit">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => router.back()}
                    className="absolute top-4 left-4 z-20 bg-background/60 backdrop-blur-sm hover:bg-background/80 rounded-full"
                    aria-label="Go back"
                >
                    <ArrowLeft className="h-5 w-5" />
                </Button>

                <Carousel setApi={setApi} className="w-full group">
                  <CarouselContent>
                    {product.images.map((img, index) => (
                      <CarouselItem key={index}>
                        <div className="relative aspect-square w-full md:rounded-2xl overflow-hidden bg-secondary">
                          <Image
                            src={img}
                            alt={`${product.name} image ${index + 1}`}
                            fill
                            className="object-cover w-full h-full"
                            priority={index === 0}
                          />
                        </div>
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  {product.images.length > 1 && (
                    <>
                      <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 z-10 h-8 w-8 rounded-full bg-white/50 hover:bg-white/80 text-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                      <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 z-10 h-8 w-8 rounded-full bg-white/50 hover:bg-white/80 text-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </>
                  )}
                </Carousel>
                
                {product.images.length > 1 && (
                  <div className="grid grid-cols-4 gap-4 px-4 md:px-0">
                    {product.images.map((img, index) => (
                      <button 
                        key={index} 
                        onClick={() => handleThumbnailClick(index)} 
                        className={cn(
                          "aspect-square rounded-xl overflow-hidden bg-secondary border-2 transition-all", 
                          current === index ? 'border-primary' : 'border-transparent'
                        )}
                      >
                          <Image
                              src={img}
                              alt={`${product.name} thumbnail ${index + 1}`}
                              fill
                              className="object-cover w-full h-full"
                          />
                      </button>
                    ))}
                  </div>
                )}
            </div>
            
            {/* Product Details */}
            <div className="bg-card md:bg-transparent rounded-t-3xl md:rounded-none -mt-8 md:mt-0 p-4 pt-6 md:p-0 relative">
                <div className="mx-auto h-1.5 w-12 rounded-full bg-border md:hidden" />
                
                <div className="mt-6 md:mt-0">
                  <p className="text-sm font-semibold text-primary">{product.category.toUpperCase()}</p>
                  <div className="mt-1 flex justify-between items-start gap-4">
                    <h1 className="text-2xl lg:text-3xl font-bold font-headline flex-1">{product.name}</h1>
                    <div className="flex items-center gap-2">
                        {reviews.length > 0 && (
                            <Link href="#reviews" className="flex-shrink-0 pt-1 hidden md:block">
                                <StarRating rating={averageRating} count={reviews.length} />
                            </Link>
                        )}
                         <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => toggleWishlist(product.id)}
                            className="rounded-full h-10 w-10 shrink-0 -mr-2"
                            aria-label="Toggle Wishlist"
                        >
                            <Heart className={cn("h-5 w-5", isLiked && "fill-red-500 text-red-500")} />
                        </Button>
                    </div>
                  </div>
                </div>

                <div className="mt-4 md:hidden">
                  {reviews.length > 0 && (
                      <Link href="#reviews" className="flex-shrink-0">
                          <StarRating rating={averageRating} count={reviews.length} />
                      </Link>
                  )}
                </div>

                <div className="mt-6 space-y-6">
                    {product.sizes.length > 1 && (
                      <div>
                        <h3 className="text-base font-semibold mb-3">Size</h3>
                        <RadioGroup value={selectedSize} onValueChange={setSelectedSize} className="flex flex-wrap gap-3">
                          {product.sizes.map(size => (
                            <div key={size}>
                              <RadioGroupItem value={size} id={`size-${size}`} className="sr-only" />
                              <Label 
                                htmlFor={`size-${size}`}
                                className={cn(
                                  "border rounded-lg px-4 h-11 flex items-center justify-center cursor-pointer transition-colors text-sm font-medium",
                                  "hover:border-primary",
                                  selectedSize === size ? "bg-primary text-primary-foreground border-primary" : "bg-secondary"
                                )}
                              >
                                {size}
                              </Label>
                            </div>
                          ))}
                        </RadioGroup>
                      </div>
                    )}
                    
                    {product.colors.length > 1 && (
                      <div>
                        <h3 className="text-base font-semibold mb-3">Color</h3>
                        <RadioGroup value={selectedColor} onValueChange={setSelectedColor} className="flex flex-wrap gap-3">
                            {product.colors.map(color => (
                                <div key={color}>
                                    <RadioGroupItem value={color} id={`color-${color}`} className="sr-only" />
                                    <Label
                                        htmlFor={`color-${color}`}
                                        className={cn(
                                            "border rounded-lg px-4 h-11 flex items-center justify-center cursor-pointer transition-colors text-sm font-medium",
                                            "hover:border-primary",
                                            selectedColor === color ? "bg-primary text-primary-foreground border-primary" : "bg-secondary"
                                        )}
                                    >
                                        {color}
                                    </Label>
                                </div>
                            ))}
                        </RadioGroup>
                      </div>
                    )}
                </div>

                <div className="hidden md:flex items-center gap-4 mt-8">
                     <p className="text-3xl font-bold text-primary">{formatPrice(product.price)}</p>
                    <Button size="lg" className="flex-1 rounded-xl" onClick={handleAddToCart}>
                      <ShoppingBag className="mr-2 h-5 w-5" />
                      Add to Cart
                    </Button>
                </div>

                {product.artistEndorsement && (
                    <div className="mt-8">
                        <Card className="bg-secondary/50 border-primary/20">
                            <CardContent className="p-4 flex items-start gap-4">
                                <ShieldCheck className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                                <div>
                                    <h4 className="font-semibold text-primary">Tested by Artists</h4>
                                    <p className="text-sm text-muted-foreground mt-1">
                                        "{product.artistEndorsement.quote}"
                                        <span className="block mt-2 font-medium">- {product.artistEndorsement.artistName}</span>
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                <Accordion type="single" collapsible defaultValue="description" className="w-full mt-8">
                  <AccordionItem value="description">
                    <AccordionTrigger className="text-base">
                      <FileText className="mr-3 text-muted-foreground" />
                      Description
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                      {product.description}
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="reviews" id="reviews">
                    <AccordionTrigger className="text-base">
                        <MessageCircle className="mr-3 text-muted-foreground" />
                        Reviews ({reviews.length})
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="flex justify-end mb-6">
                        <Dialog open={isReviewOpen} onOpenChange={setIsReviewOpen}>
                            <DialogTrigger asChild>
                                <Button>Write a Review</Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>Write a Review</DialogTitle>
                                    <DialogDescription>Share your thoughts on the {product.name}.</DialogDescription>
                                </DialogHeader>
                                <Form {...reviewForm}>
                                    <form onSubmit={reviewForm.handleSubmit(onReviewSubmit)} className="space-y-4">
                                        <FormField
                                            control={reviewForm.control}
                                            name="rating"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Your Rating</FormLabel>
                                                    <FormControl>
                                                        <div className="flex items-center gap-1">
                                                            {[1, 2, 3, 4, 5].map((star) => (
                                                                <Star
                                                                    key={star}
                                                                    className={cn("h-6 w-6 cursor-pointer transition-colors", (hoverRating || rating) >= star ? "text-yellow-400 fill-yellow-400" : "text-muted-foreground/30")}
                                                                    onMouseEnter={() => setHoverRating(star)}
                                                                    onMouseLeave={() => setHoverRating(0)}
                                                                    onClick={() => { setRating(star); field.onChange(star); }}
                                                                />
                                                            ))}
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                        <FormField control={reviewForm.control} name="title" render={({ field }) => (
                                            <FormItem><FormLabel>Review Title</FormLabel><FormControl><Input placeholder="e.g. Best watercolors ever!" {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <FormField control={reviewForm.control} name="text" render={({ field }) => (
                                            <FormItem><FormLabel>Your Review</FormLabel><FormControl><Textarea placeholder="Tell us more about your experience..." {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <FormField control={reviewForm.control} name="name" render={({ field }) => (
                                            <FormItem><FormLabel>Your Name</FormLabel><FormControl><Input placeholder="e.g. Jane Doe" {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <DialogFooter>
                                            <Button type="submit">Submit Review</Button>
                                        </DialogFooter>
                                    </form>
                                </Form>
                            </DialogContent>
                        </Dialog>
                      </div>
                      <div className="space-y-8">
                          {reviews.map(review => (
                              <div key={review.id} className="flex gap-4">
                                  <Avatar>
                                      <AvatarImage src={`https://placehold.co/40x40.png`} alt={review.author} data-ai-hint="person face" />
                                      <AvatarFallback>{review.author.split(' ').map(n=>n[0]).join('')}</AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1">
                                      <div className="flex items-center justify-between">
                                          <div>
                                              <p className="font-semibold">{review.author}</p>
                                              <p className="text-sm text-muted-foreground">{formatDate(review.date)}</p>
                                          </div>
                                          <StarRating rating={review.rating} />
                                      </div>
                                      <h4 className="font-semibold mt-4">{review.title}</h4>
                                      <p className="mt-1 text-muted-foreground">{review.text}</p>
                                  </div>
                              </div>
                          ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="qa">
                      <AccordionTrigger className="text-base">
                          <HelpCircle className="mr-3 text-muted-foreground" />
                          Questions & Answers ({qa.length})
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="flex justify-end mb-6">
                            <Dialog open={isQAOpen} onOpenChange={setIsQAOpen}>
                                <DialogTrigger asChild>
                                    <Button>Ask a Question</Button>
                                </DialogTrigger>
                                <DialogContent>
                                    <DialogHeader>
                                        <DialogTitle>Ask a Question</DialogTitle>
                                        <DialogDescription>Have a question about the {product.name}? Ask away!</DialogDescription>
                                    </DialogHeader>
                                    <Form {...qaForm}>
                                        <form onSubmit={qaForm.handleSubmit(onQASubmit)} className="space-y-4">
                                            <FormField control={qaForm.control} name="question" render={({ field }) => (
                                                <FormItem><FormLabel>Your Question</FormLabel><FormControl><Textarea placeholder="What would you like to know?" {...field} /></FormControl><FormMessage /></FormItem>
                                            )} />
                                            <FormField control={qaForm.control} name="name" render={({ field }) => (
                                                <FormItem><FormLabel>Your Name</FormLabel><FormControl><Input placeholder="e.g. John Smith" {...field} /></FormControl><FormMessage /></FormItem>
                                            )} />
                                            <DialogFooter>
                                                <Button type="submit">Submit Question</Button>
                                            </DialogFooter>
                                        </form>
                                    </Form>
                                </DialogContent>
                            </Dialog>
                        </div>
                        <div className="space-y-8">
                            {qa.map(item => (
                                <div key={item.id}>
                                    <div className="flex items-start gap-4">
                                        <div className="h-10 w-10 flex-shrink-0 flex items-center justify-center rounded-full bg-secondary text-primary">
                                            <span className="font-bold text-lg">Q</span>
                                        </div>
                                        <div className="flex-1">
                                            <p className="font-semibold">{item.question}</p>
                                            <p className="text-sm text-muted-foreground">Asked by {item.author} on {formatDate(item.date)}</p>
                                        </div>
                                    </div>
                                    {item.answer &&
                                      <div className="flex items-start gap-4 mt-4 pl-6">
                                          <div className="h-10 w-10 flex-shrink-0 flex items-center justify-center rounded-full bg-primary/10 text-primary">
                                              <span className="font-bold text-lg">A</span>
                                          </div>
                                          <div className="flex-1 pt-1">
                                              <p className="text-muted-foreground">{item.answer}</p>
                                          </div>
                                      </div>
                                    }
                                </div>
                            ))}
                        </div>
                      </AccordionContent>
                  </AccordionItem>
                </Accordion>
            </div>
        </div>
      </div>

      {/* Mobile Sticky Footer */}
      <div className="md:hidden sticky bottom-0 left-0 right-0 bg-background/95 border-t p-4 z-20 shadow-[0_-4px_12px_rgba(0,0,0,0.08)]">
        <div className="flex items-center justify-between gap-4 w-full">
            <div className="flex-1">
                <p className="text-xs text-muted-foreground">Total Price</p>
                <p className="text-xl font-bold text-primary">{formatPrice(product.price)}</p>
            </div>
            <Button size="lg" className="flex-grow-[2] rounded-xl h-12" onClick={handleAddToCart}>
                <ShoppingBag className="mr-2 h-5 w-5" />
                Add to Cart
            </Button>
        </div>
      </div>
    </>
  );
}
