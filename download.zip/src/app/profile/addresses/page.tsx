
import { addresses } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlusCircle, MapPin } from 'lucide-react';

export default function AddressesPage() {
  return (
    <div className="container max-w-4xl mx-auto my-8 md:my-12 px-4 sm:px-6">
      <div className="text-left mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">Shipping Addresses</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Manage your saved shipping addresses.
        </p>
      </div>
      
      {addresses.length === 0 ? (
         <div className="flex flex-col items-center justify-center text-center py-24 px-4 sm:px-6 border-2 border-dashed rounded-lg">
            <MapPin className="mx-auto h-24 w-24 text-muted-foreground" />
            <h2 className="mt-8 text-3xl font-headline font-bold">No Addresses Saved</h2>
            <p className="mt-4 text-muted-foreground">Add a new address to get started with faster checkout.</p>
            <Button className="mt-8">
                <PlusCircle className="mr-2 h-5 w-5" />
                Add New Address
            </Button>
        </div>
      ) : (
        <div className="space-y-6">
            <div className="flex justify-end">
                <Button>
                    <PlusCircle className="mr-2 h-5 w-5" />
                    Add New Address
                </Button>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
                {addresses.map((address) => (
                    <Card key={address.id} className="flex flex-col">
                        <CardHeader className="flex-row items-start gap-4 pb-4">
                           <MapPin className="h-8 w-8 text-primary mt-1 flex-shrink-0" />
                           <div className="flex-1">
                             <CardTitle className="text-lg flex items-center justify-between">
                                <span>{address.name}</span>
                                {address.isDefault && <Badge>Default</Badge>}
                             </CardTitle>
                             <CardDescription className="text-sm">
                                {address.addressLine1}{address.addressLine2 && `, ${address.addressLine2}`}<br />
                                {address.city}, {address.state} {address.zip}<br />
                                {address.country}
                             </CardDescription>
                           </div>
                        </CardHeader>
                        <CardContent className="flex-grow flex items-end justify-end">
                           <div className="flex gap-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10">Delete</Button>
                           </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
      )}
    </div>
  );
}
