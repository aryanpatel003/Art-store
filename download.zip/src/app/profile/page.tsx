
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { ChevronRight, Package, CreditCard, MapPin, Heart, LogOut, User as UserIcon, LifeBuoy, Shield, PackagePlus } from 'lucide-react';
import { cn } from '@/lib/utils';

// For demonstration purposes, let's create a mock user object.
// In a real application, this would come from an authentication context.
const mockUser = {
  name: 'Alex Doe',
  email: 'alex.doe@example.com',
  avatar: 'https://placehold.co/100x100.png',
  isAdmin: true, // To control visibility of the Admin Panel link
};

const profileLinks = [
  { href: "/orders", icon: Package, label: "My Orders" },
  { href: "/profile/addresses", icon: MapPin, label: "Shipping Addresses" },
  { href: "/profile/payment", icon: CreditCard, label: "Payment Methods" },
  { href: "/wishlist", icon: Heart, label: "My Favorites" },
  { href: "/profile/support", icon: LifeBuoy, label: "Customer Support" },
];

const accountLinks = [
    { href: "/profile/edit", icon: UserIcon, label: "Edit Profile", show: true },
    { href: "/profile/request-product", icon: PackagePlus, label: "Request a Product", show: true },
    { href: "/admin", icon: Shield, label: "Admin Panel", show: mockUser.isAdmin },
    { href: "#", icon: LogOut, label: "Logout", isDestructive: true, show: true },
];

export default function ProfilePage() {
  const avatarFallback = mockUser.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .slice(0, 2);

  return (
    <div className="container max-w-2xl mx-auto my-8 md:my-12 px-4 sm:px-6">
      <div className="flex flex-col items-center">
        <Avatar className="h-24 w-24 mb-4">
          <AvatarImage src={mockUser.avatar} alt={mockUser.name} data-ai-hint="artist portrait" />
          <AvatarFallback>{avatarFallback}</AvatarFallback>
        </Avatar>
        <h1 className="text-2xl font-bold">{mockUser.name}</h1>
        <p className="text-muted-foreground">{mockUser.email}</p>
      </div>
      
      <Separator className="my-6 md:my-8" />

      <div className="space-y-2">
        {profileLinks.map(link => (
          <Link href={link.href} key={link.label} className="flex items-center p-3 -mx-3 rounded-lg hover:bg-secondary transition-colors">
            <link.icon className="h-5 w-5 mr-4 text-muted-foreground" />
            <span className="flex-1 text-base">{link.label}</span>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </Link>
        ))}
      </div>
      
      <Separator className="my-6 md:my-8" />
      
      <div className="space-y-2">
         {accountLinks.filter(link => link.show).map(link => (
          <Link href={link.href} key={link.label} className={cn('flex items-center p-3 -mx-3 rounded-lg transition-colors', link.isDestructive ? 'text-destructive hover:bg-destructive/10' : 'hover:bg-secondary')}>
            <link.icon className="h-5 w-5 mr-4" />
            <span className="flex-1 text-base">{link.label}</span>
            <ChevronRight className="h-5 w-5" />
          </Link>
        ))}
      </div>
    </div>
  );
}
