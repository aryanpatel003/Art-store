
import { paymentMethods } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlusCircle, CreditCard } from 'lucide-react';

const getCardIcon = (brand: string) => {
    // In a real app, you'd have icons for each brand
    return <CreditCard className="h-8 w-8 text-primary" />;
}

export default function PaymentMethodsPage() {
  return (
    <div className="container max-w-4xl mx-auto my-8 md:my-12 px-4 sm:px-6">
      <div className="text-left mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">Payment Methods</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Manage your saved payment methods.
        </p>
      </div>
      
      {paymentMethods.length === 0 ? (
         <div className="flex flex-col items-center justify-center text-center py-24 px-4 sm:px-6 border-2 border-dashed rounded-lg">
            <CreditCard className="mx-auto h-24 w-24 text-muted-foreground" />
            <h2 className="mt-8 text-3xl font-headline font-bold">No Payment Methods</h2>
            <p className="mt-4 text-muted-foreground">Add a new payment method for faster checkout.</p>
            <Button className="mt-8">
                <PlusCircle className="mr-2 h-5 w-5" />
                Add New Payment Method
            </Button>
        </div>
      ) : (
        <div className="space-y-6">
            <div className="flex justify-end">
                <Button>
                    <PlusCircle className="mr-2 h-5 w-5" />
                    Add New Payment Method
                </Button>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
                {paymentMethods.map((method) => (
                    <Card key={method.id} className="flex flex-col">
                        <CardHeader className="flex-row items-start gap-4 pb-4">
                           {getCardIcon(method.brand)}
                           <div className="flex-1">
                             <CardTitle className="text-lg flex items-center justify-between">
                                <span>{method.brand} ending in {method.last4}</span>
                                {method.isDefault && <Badge>Default</Badge>}
                             </CardTitle>
                             <CardDescription>
                                Expires {String(method.expiryMonth).padStart(2, '0')}/{method.expiryYear}
                             </CardDescription>
                           </div>
                        </CardHeader>
                        <CardContent className="flex-grow flex items-end justify-end">
                            <div className="flex gap-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10">Delete</Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
      )}
    </div>
  );
}
