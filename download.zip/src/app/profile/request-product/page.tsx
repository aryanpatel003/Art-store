import { RequestProductForm } from "@/components/request-product-form";

export default function RequestProductPage() {
  return (
    <div className="container max-w-2xl mx-auto my-8 md:my-12 px-4 sm:px-6">
       <div className="text-left mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">Request a Product</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Help us improve our store by suggesting new products.
        </p>
      </div>
      <RequestProductForm />
    </div>
  );
}
