
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import Link from 'next/link';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Phone, MessageSquare } from "lucide-react";

const supportFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  subject: z.string().min(5, "Subject must be at least 5 characters."),
  message: z.string().min(10, "Message must be at least 10 characters.").max(1000, "Message cannot exceed 1000 characters."),
});

type SupportFormValues = z.infer<typeof supportFormSchema>;

export default function CustomerSupportPage() {
    const { toast } = useToast();

    const form = useForm<SupportFormValues>({
        resolver: zodResolver(supportFormSchema),
        defaultValues: {
            name: "Alex Doe",
            email: "alex.doe@example.com",
            subject: "",
            message: "",
        },
    });

    function onSubmit(data: SupportFormValues) {
        console.log(data);
        toast({
            title: "Message Sent!",
            description: "Thank you for contacting us. We will get back to you shortly.",
            action: <CheckCircle className="text-green-500" />,
        });
        form.reset({
            name: "Alex Doe",
            email: "alex.doe@example.com",
            subject: "",
            message: ""
        });
    }

  return (
    <div className="container max-w-4xl mx-auto my-8 md:my-12 px-4 sm:px-6">
      <div className="text-left mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">Customer Support</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Have a question or need assistance? We're here to help.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <Card>
            <CardHeader className="flex-row items-center gap-4 pb-4">
                <Phone className="h-8 w-8 text-primary flex-shrink-0" />
                <div>
                    <CardTitle className="text-lg">Call Us</CardTitle>
                    <CardDescription>Speak directly with our team.</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                <p className="text-lg font-semibold">+1 (800) 555-0199</p>
                <p className="text-sm text-muted-foreground">Mon-Fri, 9am - 5pm EST</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex-row items-center gap-4 pb-4">
                <MessageSquare className="h-8 w-8 text-primary flex-shrink-0" />
                <div>
                    <CardTitle className="text-lg">WhatsApp</CardTitle>
                    <CardDescription>Send a message for quick help.</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                <Button asChild>
                    <Link href="https://wa.me/18005550199" target="_blank">Chat with Us</Link>
                </Button>
            </CardContent>
        </Card>
      </div>

      <Card>
          <CardHeader>
              <CardTitle>Send an Email</CardTitle>
              <CardDescription>Alternatively, fill out the form below and we'll get back to you via email.</CardDescription>
          </CardHeader>
          <CardContent>
              <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                          <FormField
                              control={form.control}
                              name="name"
                              render={({ field }) => (
                                  <FormItem>
                                      <FormLabel>Full Name</FormLabel>
                                      <FormControl>
                                          <Input placeholder="Your full name" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )}
                          />
                          <FormField
                              control={form.control}
                              name="email"
                              render={({ field }) => (
                                  <FormItem>
                                      <FormLabel>Email Address</FormLabel>
                                      <FormControl>
                                          <Input type="email" placeholder="your.email@example.com" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )}
                          />
                      </div>
                       <FormField
                          control={form.control}
                          name="subject"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Subject</FormLabel>
                                  <FormControl>
                                      <Input placeholder="e.g., Question about an order" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                  </FormItem>
                              )}
                          />
                      <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Message</FormLabel>
                                  <FormControl>
                                      <Textarea
                                        placeholder="Please describe your issue or question in detail..."
                                        className="min-h-[150px]"
                                        {...field} 
                                      />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}
                      />
                      <div className="flex justify-end">
                          <Button type="submit">Send Message</Button>
                      </div>
                  </form>
              </Form>
          </CardContent>
      </Card>
    </div>
  );
}
