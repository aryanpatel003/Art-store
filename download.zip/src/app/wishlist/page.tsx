
"use client";

import { useWishlist } from '@/hooks/use-wishlist';
import { products } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { Button } from '@/components/ui/button';
import { Heart } from 'lucide-react';
import Link from 'next/link';

export default function WishlistPage() {
  const { wishlistItems } = useWishlist();

  const likedProducts = products.filter(product => wishlistItems.includes(product.id));

  if (likedProducts.length === 0) {
    return (
      <div className="container text-center py-24 px-4 sm:px-6">
        <Heart className="mx-auto h-24 w-24 text-muted-foreground" />
        <h1 className="mt-8 text-3xl font-headline font-bold">Your Favorites is Empty</h1>
        <p className="mt-4 text-muted-foreground">Looks like you haven't liked anything yet.</p>
        <Button asChild className="mt-8">
          <Link href="/collections">Explore Products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container my-8 md:my-12 px-4 sm:px-6">
      <div className="text-center mb-8 md:mb-12">
        <h1 className="text-4xl font-headline font-bold">My Favorites</h1>
        <p className="mt-2 text-lg text-muted-foreground">A collection of your favorite art supplies.</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
        {likedProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
