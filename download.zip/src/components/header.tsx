
"use client";

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { FormEvent, useState } from 'react';
import { ShoppingBag, Paintbrush, Heart, User, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

const navLinks = [
  { href: '/collections', label: 'Collections' },
  { href: '/about', label: 'About' },
  { href: '/profile/support', label: 'Contact' }
];

export function Header() {
  const { cartCount } = useCart();
  const { wishlistCount } = useWishlist();
  const pathname = usePathname();
  const router = useRouter();
  const [query, setQuery] = useState('');

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (!query.trim()) {
      return;
    }
    router.push(`/search?q=${encodeURIComponent(query.trim())}`);
  };
  
  const showSearchBar = pathname === '/' || pathname.startsWith('/collections');

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between gap-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-2">
              <Paintbrush className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
              <h1 className="font-headline text-xl sm:text-2xl font-bold leading-none">
                Canvas & Palette
              </h1>
            </Link>
          </div>

          <nav className="hidden lg:flex">
              <ul className="flex items-center gap-6">
                  {navLinks.map(link => (
                      <li key={link.href}>
                          <Link 
                              href={link.href} 
                              className={cn(
                                  "text-sm font-medium transition-colors hover:text-primary",
                                  pathname === link.href ? "text-primary" : "text-muted-foreground"
                              )}
                          >
                              {link.label}
                          </Link>
                      </li>
                  ))}
              </ul>
          </nav>
          
          {showSearchBar && (
            <div className="hidden md:flex flex-1 max-w-sm">
              <form onSubmit={handleSearch} className="w-full flex">
                <Input
                  type="search"
                  placeholder="Search products..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="h-10 rounded-r-none border-r-0"
                />
                <Button type="submit" size="icon" className="h-10 w-12 rounded-l-none bg-accent hover:bg-accent/90">
                  <Search className="h-5 w-5 text-accent-foreground" />
                </Button>
              </form>
            </div>
          )}

          <div className="flex items-center justify-end gap-1 sm:gap-2">
            <div className="hidden md:flex items-center gap-1 sm:gap-2">
              <Link href="/wishlist" aria-label={`Wishlist with ${wishlistCount} items`}>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <div className="relative">
                    <Heart className="h-5 w-5" />
                    {wishlistCount > 0 && <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-xs text-accent-foreground">{wishlistCount}</span>}
                  </div>
                  <span className="sr-only">Wishlist</span>
                </Button>
              </Link>

              <Link href="/profile" aria-label="User Profile">
                <Button variant="ghost" size="icon" className="rounded-full">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Profile</span>
                </Button>
              </Link>
            </div>

            <Link href="/cart" aria-label={`Shopping cart with ${cartCount} items`}>
              <Button variant="ghost" size="icon" className="rounded-full">
                <div className="relative">
                  <ShoppingBag className="h-5 w-5" />
                  {cartCount > 0 && <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-xs text-accent-foreground">{cartCount}</span>}
                </div>
                <span className="sr-only">Cart</span>
              </Button>
            </Link>
          </div>
        </div>
        {showSearchBar && (
          <div className="md:hidden pb-3">
            <form onSubmit={handleSearch} className="w-full flex">
              <Input
                type="search"
                placeholder="Search products..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="h-10 rounded-r-none border-r-0"
              />
              <Button type="submit" size="icon" className="h-10 w-12 rounded-l-none bg-accent hover:bg-accent/90">
                <Search className="h-5 w-5 text-accent-foreground" />
              </Button>
            </form>
          </div>
        )}
      </div>
    </header>
  );
}
